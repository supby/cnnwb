﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Markup;
using TaskDialogInterop;

namespace CNNWB
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application, IDisposable 
	{
		MainViewWindow mainWindow;
		
		static App()
		{
			FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement), new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));
		}

		~App()
		{
			// In case the client forgets to call
			// Dispose , destructor will be invoked for
			Dispose(false);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				// Free managed objects.
				mainWindow.Closing -= mainWindow_Closing;
				mainWindow.Dispose();
			}
			// Free unmanaged objects
		}

		public void Dispose()
		{
			Dispose(true);
			// Ensure that the destructor is not called
			GC.SuppressFinalize(this);
		}

		protected override void OnStartup(StartupEventArgs e)
		{
			base.OnStartup(e);
		   
			mainWindow = new MainViewWindow();
			mainWindow.Closing += mainWindow_Closing;
			mainWindow.Show();
		}

		private void mainWindow_Closing(object sender, CancelEventArgs e)
		{
			if (mainWindow.ShowCloseApplicationDialog)
			{
				TaskDialogOptions config = new TaskDialogOptions();
				config.Owner = mainWindow;
				config.MainIcon = VistaTaskDialogIcon.None;
				config.MainInstruction = "Do you really want to quit ?";
				config.Title = "Exit Application";
				config.CustomButtons = new string[] { "&Yes", "&No" };
				config.DefaultButtonIndex = 1;
				config.AllowDialogCancellation = false;
				TaskDialogResult res = TaskDialog.Show(config);

				if (res.CustomButtonResult == 0)
				{
					e.Cancel = false;
					CNNWB.Properties.Settings.Default.Save();
				   
				}
				else
					e.Cancel = true;
			}
			else
			{
				CNNWB.Properties.Settings.Default.Save();
				e.Cancel = false;
			}
		}
	}
}
