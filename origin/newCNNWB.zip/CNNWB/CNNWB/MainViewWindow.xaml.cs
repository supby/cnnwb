﻿using CNNWB.Common;
using CNNWB.Dialogs;
using CNNWB.Model;
using CNNWB.ViewModel;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using TaskDialogInterop;

namespace CNNWB
{
	public partial class MainViewWindow : Window, IDisposable 
	{
		public DataProvider DataProvider;
		public bool ShowCloseApplicationDialog = true;
		public readonly PageViewModel pageViewModel;
		public static RoutedCommand ApplicationExitCmd = new RoutedCommand();
		public static RoutedCommand PageSetupCmd = new RoutedCommand();
		public static RoutedCommand AboutCmd = new RoutedCommand();
		public static string StorageDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\CNNWB";
		public readonly string TrainingParametersDirectory = StorageDirectory + @"\Training Parameters";
		public readonly string TrainingSchemesDirectory = StorageDirectory + @"\Training Schemes";
		public readonly string DefinitionsDirectory = StorageDirectory + @"\Definitions";
	
		private StringBuilder progressText = new StringBuilder();
		private TrainingPageViewModel trainingPVM = null;
		private TestingPageViewModel testingPVM = null;
		private CalculatePageViewModel calculatePVM = null;
		private DesignPageViewModel designPVM = null;
		private Microsoft.Win32.OpenFileDialog openFileDialog;
		private Microsoft.Win32.SaveFileDialog saveFileDialog;
		private bool cleanUpViews = true;
		private bool needRefreshWeightsView = true;
		private PerformanceCounter cpu_using = new PerformanceCounter();
		
		public MainViewWindow()
		{
			InitializeComponent();

			cpu_using.CategoryName = "Processor";
			cpu_using.CounterName = "% Processor Time";
			cpu_using.InstanceName = "_Total";
			
			// Assign and create the DataProvider and default network to the global pageViewModel that acts as the DataContext in our MainView.
			DataProvider = new DataProvider(StorageDirectory);
			pageViewModel = new PageViewModel(DataProvider, InitializeDefaultNeuralNetwork());
			pageViewModel.MaxDegreeOfParallelism = Environment.ProcessorCount;
			pageViewModel.DataProvider.RaiseDataLoadedEvent += new EventHandler<DataProviderEventArgs>(HandleDataLoadedEvent);
			pageViewModel.DataProvider.RaiseDataProgressEvent += new EventHandler<DataProviderEventArgs>(HandleDataProgressEvent);
			pageViewModel.PageChange += OnViewModelPageChange;
			MainView.DataContext = pageViewModel;
		}
		
		~MainViewWindow()
		{
			// In case the client forgets to call
			// Dispose , destructor will be invoked for
			Dispose(false);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				// Free managed objects.
				designPVM.Invert -= OnViewModelInvert;
				trainingPVM.Start -= OnViewModelStart;
				trainingPVM.Stop -= OnViewModelStop;
				trainingPVM.Pause -= OnViewModelPause;
				trainingPVM.Editor -= OnViewModelEditor;
				trainingPVM.Forget -= OnViewModelForget;
				testingPVM.Start -= OnViewModelStart;
				testingPVM.Stop -= OnViewModelStop;
				testingPVM.Pause -= OnViewModelPause;
				calculatePVM.Calculate -= OnViewModelCalculate;
				calculatePVM.Refresh -= OnViewModelRefresh;
				calculatePVM.Invert -= OnViewModelInvert;
				calculatePVM.UseTrainingSetChanged -= OnViewModelUseTrainingSetChanged;
				calculatePVM.UseDistortionsChanged -= OnViewModelUseDistortionsChanged;
				pageViewModel.PageChange -= OnViewModelPageChange;
				
				if (pageViewModel.DataProvider != null)
					pageViewModel.DataProvider.Dispose();

				if (pageViewModel.NeuralNetwork != null)
					pageViewModel.NeuralNetwork.Dispose();

				if (DataProvider != null)
					DataProvider.Dispose();
			}
			// Free unmanaged objects
		}

		public void Dispose()
		{
			Dispose(true);
			// Ensure that the destructor is not called
			GC.SuppressFinalize(this);
		}

		private NeuralNetwork InitializeDefaultNeuralNetwork()
		{
			//NeuralNetwork network = new NeuralNetwork(DataProvider, "Simard-6", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.MNIST, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
			//network.AddLayer(LayerTypes.Input, 1, 32, 32);
			//network.AddLayer(LayerTypes.ConvolutionalSubsampling, ActivationFunctions.Tanh, 6, 14, 14, 5, 5);
			//network.AddLayer(LayerTypes.ConvolutionalSubsampling, ActivationFunctions.Tanh, 50, 5, 5, 5, 5);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 100);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
			//network.InitializeWeights();

			//NeuralNetwork network = new NeuralNetwork(DataProvider, "Simard-16", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.MNIST, TrainingStrategy.SGDLevenbergMarquardt, 0.1D);
			//network.AddLayer(LayerTypes.Input, 1, 32, 32);
			//network.AddLayer(LayerTypes.ConvolutionalSubsampling, ActivationFunctions.Tanh, 16, 14, 14, 5, 5);
			//network.AddLayer(LayerTypes.ConvolutionalSubsampling, ActivationFunctions.Tanh, 64, 5, 5, 5, 5);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 196);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
			//network.InitializeWeights();

            //NeuralNetwork network = new NeuralNetwork(DataProvider, "LeNet-5", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.MNIST, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
            //network.AddLayer(LayerTypes.Input, 1, 32, 32);
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.Tanh, 6, 28, 28, 5, 5, 1, 1);
            //network.AddLayer(LayerTypes.AvgPooling, ActivationFunctions.Tanh, 6, 14, 14, 2, 2, 2, 2);
            //bool[] maps = new bool[6 * 16]
            //{
            //    true,  false, false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,  true,
            //    true,  true,  false, false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,
            //    true,  true,  true,  false, false, false, true,  true,  true,  false, false, true,  false, true,  true,  true,
            //    false, true,  true,  true,  false, false, true,  true,  true,  true,  false, false, true,  false, true,  true,
            //    false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,  true,  false, true,
            //    false, false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,  true,  true
            //};
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.Tanh, 16, 10, 10, 5, 5, 1, 1, 0, 0, new Mappings(maps));
            //network.AddLayer(LayerTypes.AvgPooling, ActivationFunctions.Tanh, 16, 5, 5, 2, 2, 2, 2);
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.Tanh, 120, 1, 1, 5, 5, 1, 1);
            //network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
            //network.InitializeWeights();

			//NeuralNetwork network = new NeuralNetwork(DataProvider, "LeNet-5", 10, 1D, LossFunctions.CrossEntropy, DataProviderSets.MNIST, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
			//network.AddLayer(LayerTypes.Input, 1, 32, 32);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 6, 28, 28, 5, 5);
			//network.AddLayer(LayerTypes.AvgPooling, ActivationFunctions.Ident, 6, 14, 14, 2, 2, 2, 2);
			//bool[] maps = new bool[6 * 16]
			//{
			//    true,  false, false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,  true,
			//    true,  true,  false, false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,
			//    true,  true,  true,  false, false, false, true,  true,  true,  false, false, true,  false, true,  true,  true,
			//    false, true,  true,  true,  false, false, true,  true,  true,  true,  false, false, true,  false, true,  true,
			//    false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,  true,  false, true,
			//    false, false, false, true,  true,  true,  false, false, true,  true,  true,  true,  false, true,  true,  true
			//};
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 16, 10, 10, 5, 5, 1, 1, 0, 0, new Mappings(maps));
			//network.AddLayer(LayerTypes.AvgPooling, ActivationFunctions.Ident, 16, 5, 5, 2, 2, 2, 2);
			//network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 120, 1, 1, 5, 5);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.SoftMax, 10);
			//network.InitializeWeights();
			
			//NeuralNetwork network = new NeuralNetwork(DataProvider, "MyNet-16", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.MNIST, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
			//network.AddLayer(LayerTypes.Input, 1, 32, 32);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.Tanh, 16, 28, 28, 5, 5);
			//network.AddLayer(LayerTypes.AvgPooling, ActivationFunctions.Tanh, 16, 14, 14, 2, 2);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.Tanh, 64, 10, 10, 5, 5, 1, 1, 0, 0, new Mappings(16, 64, 66, 1));
			//network.AddLayer(LayerTypes.AvgPooling, ActivationFunctions.Tanh, 64, 5, 5, 2, 2);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.Tanh, 256, 1, 1, 5, 5, 1, 1, 0, 0, new Mappings(64, 256, 66, 2));
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
			//network.InitializeWeights();

            //NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-A", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.CIFAR10, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
            //network.AddLayer(LayerTypes.Input, 3, 32, 32);
            //bool[] maps = new bool[3 * 64]
            //{
            //    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true
            //};
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 28, 28, 5, 5, 1, 1, 0, 0, new Mappings(maps));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 14, 14, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 10, 10, 5, 5, 1, 1, 0, 0, new Mappings(64, 64, 66, 1));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 5, 5, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 64, 3, 3, 3, 3, 1, 1, 0, 0, new Mappings(64, 64, 66, 2));
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 386, 1, 1, 3, 3, 1, 1, 0, 0, 50);
            //network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.SoftSign, 10);
            //network.InitializeWeights();

            NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-Z2", 10, 1D, LossFunctions.CrossEntropy, DataProviderSets.CIFAR10, TrainingStrategy.SGDLevenbergMarquardt);
            network.AddLayer(LayerTypes.Input, 3, 32, 32);
            bool[] maps = new bool[3 * 64]
            {
                true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
                false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
                false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true
            };
            //bool[] maps = new bool[3 * 96]
            //{
            //    true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false,
            //    false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false,
            //    false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true,  false, false, true
            //};
            network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 28, 28, 5, 5, 1, 1, 0, 0, new Mappings(maps));
            network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 14, 14, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.LocalResponseNormalizationCM, ActivationFunctions.None, 64, 14, 14, 3, 3);
            network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 10, 10, 5, 5, 1, 1, 0, 0, new Mappings(64, 64, 66, 1));
            //network.AddLayer(LayerTypes.LocalResponseNormalizationCM, ActivationFunctions.None, 64, 10, 10, 3, 3);
            network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 5, 5, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 64, 1, 1, 5, 5, 1, 1, 0, 0, new Mappings(64, 64, 66, 2));
            network.AddLayer(LayerTypes.Local, ActivationFunctions.Logistic, 384, 1, 1, 5, 5, 1, 1, 0, 0, 50);
            network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.SoftMax, 10);
            network.InitializeWeights();
            //network.LoadWeights(StorageDirectory + @"\CNN-CIFAR10-Z2 (2259 errors).weights-bin");

            //NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-B2", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.CIFAR10, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
            //network.AddLayer(LayerTypes.Input, 3, 32, 32);
            //bool[] maps = new bool[3 * 64]
            //{
            //    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true
            //};
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 28, 28, 5, 5, 1, 1, 0, 0, new Mappings(maps));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 14, 14, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 10, 10, 5, 5, 1, 1, 0, 0, new Mappings(64, 64, 66, 1));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 5, 5, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.Tanh, 512, 1, 1, 5, 5, 1, 1, 0, 0, 50);
            //network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
            //network.InitializeWeights();

            //NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-Z3", 10, 1D, LossFunctions.CrossEntropy, DataProviderSets.CIFAR10, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
            //network.AddLayer(LayerTypes.Input, 3, 32, 32);
            //bool[] maps = new bool[3 * 64]
            //{
            //    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true
            //};
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 32, 32, 5, 5, 1, 1, 2, 2, new Mappings(maps));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 16, 16, 3, 3, 2, 2);
            ////network.AddLayer(LayerTypes.LocalResponseNormalizationCM, ActivationFunctions.None, 64, 16, 16, 5, 5);
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 16, 16, 5, 5, 1, 1, 2, 2, new Mappings(64, 64, 66, 1));
            ////network.AddLayer(LayerTypes.LocalResponseNormalizationCM, ActivationFunctions.None, 64, 16, 16, 5, 5);
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 8, 8, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 32, 8, 8, 3, 3, 1, 1, 1, 1, new Mappings(64, 32, 50, 2));
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.SoftSign, 32, 8, 8, 3, 3, 1, 1, 1, 1, 50);
            //network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.SoftMax, 10);
            //network.InitializeWeights();

            //NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-C", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.CIFAR10, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
            //network.AddLayer(LayerTypes.Input, 3, 32, 32);
            //bool[] maps = new bool[3 * 64]
            //{
            //    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true
            //};
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 28, 28, 5, 5, 1, 1, 0, 0, new Mappings(maps));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 14, 14, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 10, 10, 5, 5, 1, 1, 0, 0, new Mappings(64, 64, 66, 1));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 5, 5, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 32, 5, 5, 3, 3, 1, 1, 1, 1, new Mappings(64, 32, 50, 2));
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 32, 5, 5, 3, 3, 1, 1, 1, 1, 50);
            //network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
            //network.InitializeWeights();

            //NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-Z4", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.CIFAR10, TrainingStrategy.SGDLevenbergMarquardt, 0.02D, 2000, false);
            //network.AddLayer(LayerTypes.Input, 3, 32, 32);
            ////bool[] maps = new bool[3 * 64]
            ////{
            ////    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true, true, true, true, true, true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true, true, true, true, true, true, false, true,  false, true,  false, true,  false, true,
            ////    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true, true, true, true, true, true, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, true, true, true, true, true, true,  false, true,  false, true,  false, true,  false,
            ////    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, true, true, true, true, true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, true, true, true, true, true, false, true,  false, true,  false, true,  false, true
            ////};
            //bool[] maps = new bool[3 * 64]
            //{
            //    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
            //    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true
            //};
            ////bool[] maps = new bool[3 * 48]    //Z3
            ////{
            ////    true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
            ////    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
            ////    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true 
            ////};

            ////bool[] maps = new bool[3 * 48]    //Z3
            ////{
            ////    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true, true, true, true, true, true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false,
            ////    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true, true, true, true, true, true, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,
            ////    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, true, true, true, true, true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true
            ////};
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 32, 32, 5, 5, 1, 1, 2, 2, new Mappings(maps));
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 16, 16, 3, 3, 2, 2);
            ////network.AddLayer(LayerTypes.LocalContrastNormalization, ActivationFunctions.None, 64, 16, 16, 5, 5);
            //network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 16, 16, 5, 5, 1, 1, 2, 2, new Mappings(64, 64, 66, 1));
            ////network.AddLayer(LayerTypes.LocalContrastNormalization, ActivationFunctions.None, 64, 16, 16, 5, 5);
            //network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 8, 8, 3, 3, 2, 2);
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 32, 8, 8, 3, 3, 1, 1, 1, 1, new Mappings(64, 32, 50, 2));
            //network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 32, 8, 8, 3, 3, 1, 1, 1, 1, 50);
            //network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.SoftSign, 10);
            //network.InitializeWeights();
			
			//NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-D", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.CIFAR10, TrainingStrategy.SGDLevenbergMarquardt, 0.02D);
			//network.AddLayer(LayerTypes.Input, 3, 32, 32);
			//bool[] maps = new bool[3 * 64]
			//{
			//    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
			//    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true, 
			//    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true
			//};
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 32, 32, 5, 5, 1, 1, 2, 2, new Mappings(maps));
			//network.AddLayer(LayerTypes.MaxPoolingWeightless, ActivationFunctions.Ident, 64, 16, 16, 3, 3, 2, 2);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 16, 16, 3, 3, 1, 1, 1, 1, new Mappings(64, 64, 50, 1));
			//network.AddLayer(LayerTypes.AvgPoolingWeightless, ActivationFunctions.Ident, 64, 8, 8, 3, 3, 2, 2);
			//network.AddLayer(LayerTypes.Local, ActivationFunctions.BReLU, 32, 8, 8, 3, 3, 1, 1, 1, 1, new Mappings(64, 32, 50, 2));
			//network.AddLayer(LayerTypes.Local, ActivationFunctions.Tanh, 32, 8, 8, 3, 3, 1, 1, 1, 1, 50);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
			////network.InitializeWeights();

			//NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-CIFAR10-G", 10, 0.8D, LossFunctions.MeanSquareError, DataProviderSets.CIFAR10, TrainingStrategy.SGD, 0.02D);
			//network.AddLayer(LayerTypes.Input, 3, 32, 32);
			//bool[] maps = new bool[3 * 48]
			//{
			//    true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true, true, true, true, true, true, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false,
			//    false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false, false, false, false, true,  true,  true, true, true, true, true, true, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,
			//    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, true, true, true, true, true, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  true,  true,  true
			//};
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 48, 32, 32, 5, 5, 1, 1, 2, 2, new Mappings(maps));
			//network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 48, 16, 16, 3, 3, 2, 2);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 64, 16, 16, 5, 5, 1, 1, 2, 2, new Mappings(48, 64, 66, 1));
			//network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 64, 8, 8, 3, 3, 2, 2);
			//network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 24, 8, 8, 3, 3, 1, 1, 1, 1, new Mappings(64, 24, 50, 2));
			//network.AddLayer(LayerTypes.Local, ActivationFunctions.Tanh, 24, 8, 8, 3, 3, 1, 1, 1, 1, 50);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.Tanh, 10);
			//network.InitializeWeights();

			//NeuralNetwork network = new NeuralNetwork(DataProvider, "CNN-MNIST-A", 10, 1D, LossFunctions.CrossEntropy, DataProviderSets.MNIST, TrainingStrategy.SGD, 0.02D);
			//network.AddLayer(LayerTypes.Input, 1, 32, 32);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 32, 24, 24, 9, 9, 1, 1, 0, 0);
			//network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 32, 12, 12, 3, 3, 2, 2);
			//network.AddLayer(LayerTypes.Convolutional, ActivationFunctions.ReLU, 32, 8, 8, 5, 5, 1, 1, 0, 0, new Mappings(32, 32, 66));
			//network.AddLayer(LayerTypes.StochasticPooling, ActivationFunctions.Ident, 32, 4, 4, 3, 3, 2, 2);
			//network.AddLayer(LayerTypes.Local, ActivationFunctions.ReLU, 256, 1, 1, 4, 4, 1, 1, 0, 0, 50);
			//network.AddLayer(LayerTypes.FullyConnected, ActivationFunctions.SoftMax, 10);
			//network.InitializeWeights();

			network.RaiseNetworkProgressEvent += new EventHandler<EventArgs>(NetworkProgressEvent);
			network.RaiseAddUnrecognizedTestSampleEvent += new EventHandler<AddUnrecognizedTestSampleEventArgs>(AddUnrecognizedTestSampleEvent);

			return network;
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			MainView.PageViews.IsEnabled = false;
			
			string appPath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
			
			if (!Directory.Exists(TrainingSchemesDirectory))
				Directory.CreateDirectory(TrainingSchemesDirectory);
			
			// Copy standard training schemes
            if (!File.Exists(TrainingSchemesDirectory + @"\LeCun.scheme-xml"))
                File.Copy(appPath + @"\Training Schemes\LeCun.scheme-xml", TrainingSchemesDirectory + @"\LeCun.scheme-xml");

			if (!Directory.Exists(TrainingParametersDirectory))
				Directory.CreateDirectory(TrainingParametersDirectory);
		   
			// Copy standard training parameter
            //if (!File.Exists(TrainingParametersDirectory + @"\CIFAR-10-SoftMax.parameters-xml"))
            //    File.Copy(appPath + @"\Parameters\CIFAR-10-SoftMax.parameters-xml", TrainingParametersDirectory + @"\CIFAR-10-SoftMax.parameters-xml");
            if (!File.Exists(TrainingParametersDirectory + @"\MNIST-MSE.parameters-xml"))
                File.Copy(appPath + @"\Parameters\MNIST-MSE.parameters-xml", TrainingParametersDirectory + @"\MNIST-MSE.parameters-xml");
		   
			if (!Directory.Exists(DefinitionsDirectory))
				Directory.CreateDirectory(DefinitionsDirectory);

			// Copy standard definitions
            File.Copy(appPath + @"\Definitions\LeNet-5.definition-xml", DefinitionsDirectory + @"\LeNet-5.definition-xml", true);
            File.Copy(appPath + @"\Definitions\CNN-CIFAR10-Z2.definition-xml", DefinitionsDirectory + @"\CNN-CIFAR10-Z2.definition-xml", true);
			File.Copy(appPath + @"\Definitions\CNN-CIFAR10-Z4.definition-xml", DefinitionsDirectory + @"\CNN-CIFAR10-Z4.definition-xml", true);
			//File.Copy(appPath + @"\Definitions\MyNet-16.definition-xml", DefinitionsDirectory + @"\MyNet-16.definition-xml", true);
			//File.Copy(appPath + @"\Definitions\Simard-16.definition-xml", DefinitionsDirectory + @"\Simard-16.definition-xml", true);
			//File.Copy(appPath + @"\Definitions\Simard-6.definition-xml", DefinitionsDirectory + @"\Simard-6.definition-xml", true);

            if (!File.Exists(StorageDirectory + @"\CNN-CIFAR10-Z2 (2259 errors).weights-bin"))
                File.Copy(appPath + @"\Weights\CNN-CIFAR10-Z2 (2259 errors).weights-bin", StorageDirectory + @"\CNN-CIFAR10-Z2 (2259 errors).weights-bin");
			
            // Check if the CIFAR-10 and MNIST datasets are both available otherwise download the missing ones
			bool filesAvailable = pageViewModel.DataProvider.AllDataSetFilesAvailable();
			if (!filesAvailable)
			{
				if (NativeMethods.IsConnectedToInternet())
				{
					DownloadDatasets DownloadDatasetsDialog = new DownloadDatasets();
					DownloadDatasetsDialog.DataProvider = pageViewModel.DataProvider;
					DownloadDatasetsDialog.ShowDialog();
					filesAvailable = DownloadDatasetsDialog.AllDownloaded;
				}
				else
				{
					TaskDialogOptions config = new TaskDialogOptions();
					config.Owner = this;
					config.MainIcon = VistaTaskDialogIcon.Information;
					config.MainInstruction = "No Internet connection available to download the necessary datasets.";
					config.Title = "Exiting application";
					config.CommandButtons = new string[] { "&OK" };
					config.AllowDialogCancellation = false;
					TaskDialog.Show(config);
				}
			}

			if (filesAvailable)
			{
				pageViewModel.DataProvider.LoadDataset(pageViewModel.NeuralNetwork.DataProviderSet);
				
				OnViewModelPageChange(this, EventArgs.Empty);
				this.Title = "Convolutional Neural Network Workbench - " + pageViewModel.NeuralNetwork.Name;
				
			}
			else
			{
				ShowCloseApplicationDialog = false;
				Application.Current.Shutdown(0);
			}
		}

		private void OnViewModelPageChange(object sender, EventArgs e)
		{
			Mouse.OverrideCursor = Cursors.Wait;

			switch (pageViewModel.CurrentContext)
			{
				case ContextTypes.Training:
					if (trainingPVM == null)
					{
						trainingPVM = MainView.PageContentControl.Content as TrainingPageViewModel;
						trainingPVM.Start += OnViewModelStart;
						trainingPVM.Stop += OnViewModelStop;
						trainingPVM.Pause += OnViewModelPause;
						trainingPVM.Editor += OnViewModelEditor;
						trainingPVM.Forget += OnViewModelForget;
					}
					pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;
					pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
					pageViewModel.CommandToolBar[2].Visibility = Visibility.Collapsed;
					pageViewModel.CommandToolBar[3].Visibility = Visibility.Visible;
					pageViewModel.CommandToolBar[4].Visibility = Visibility.Visible;
					
					break;

				case ContextTypes.Testing:
					if (testingPVM == null)
					{
						testingPVM = MainView.PageContentControl.Content as TestingPageViewModel;
						testingPVM.Start += OnViewModelStart;
						testingPVM.Stop += OnViewModelStop;
						testingPVM.Pause += OnViewModelPause;

						testingPVM.SeverityFactor = Properties.Settings.Default.SeverityFactor;
						testingPVM.MaxScaling = Properties.Settings.Default.MaxScaling;
						testingPVM.MaxRotation = Properties.Settings.Default.MaxRotation;
						testingPVM.ElasticSigma = Properties.Settings.Default.ElasticSigma;
						testingPVM.ElasticScaling = Properties.Settings.Default.ElasticScaling;
					}
					pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;
					pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
					pageViewModel.CommandToolBar[2].Visibility = Visibility.Collapsed;
					break;

				case ContextTypes.Calculate:
					if (calculatePVM == null)
					{
						calculatePVM = MainView.PageContentControl.Content as CalculatePageViewModel;
						calculatePVM.Calculate  += OnViewModelCalculate;
						calculatePVM.SampleIndexChanged += OnSampleIndexChanged;
						calculatePVM.UseTrainingSetChanged += OnViewModelUseTrainingSetChanged;
						calculatePVM.UseDistortionsChanged += OnViewModelUseDistortionsChanged;
						calculatePVM.Refresh += OnViewModelRefresh;
						calculatePVM.Invert += OnViewModelInvert;
						calculatePVM.SeverityFactor = Properties.Settings.Default.SeverityFactor;
						calculatePVM.MaxScaling = Properties.Settings.Default.MaxScaling;
						calculatePVM.MaxRotation = Properties.Settings.Default.MaxRotation;
						calculatePVM.ElasticSigma = Properties.Settings.Default.ElasticSigma;
						calculatePVM.ElasticScaling = Properties.Settings.Default.ElasticScaling;

						OnSampleIndexChanged(this, new EventArgs());
					}
					pageViewModel.CommandToolBar[0].IsEnabled = true;
										
					if (calculatePVM.Result.Length > 0)
						pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
					else
						pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
					break;

				case ContextTypes.Design:
					if (designPVM == null)
					{
						designPVM = MainView.PageContentControl.Content as DesignPageViewModel;
						designPVM.Invert += OnViewModelInvert;
						needRefreshWeightsView = true;
					}
					pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;

					if (needRefreshWeightsView)
						RefreshWeightsView();
					break;
			}
			Mouse.OverrideCursor = null;
		}

		private void RefreshWeightsView(bool justUpdateExistingWeightBitmaps = true)
		{
			if (needRefreshWeightsView || justUpdateExistingWeightBitmaps)
			{
				int selectedIndex;

				if (designPVM.TabItems != null && justUpdateExistingWeightBitmaps)
				{
					selectedIndex = designPVM.SelectedLayerIndex;
					TabItem tb;
					Grid grid;
					ScrollViewer scr;
					double ho, vo;
					foreach (Layer layer in pageViewModel.NeuralNetwork.Layers.Skip(1))
					{
						int index = layer.LayerIndex - 1;

						switch (layer.LayerType)
						{
							case LayerTypes.Local:
								designPVM.TabItems[index].Content = GetLocalLayerWeightsBitmap(layer, designPVM.Inverted);
								break;

							case LayerTypes.Convolutional:
							case LayerTypes.ConvolutionalSubsampling:
								tb = designPVM.TabItems[index];
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								ho = scr.HorizontalOffset;
								vo = scr.VerticalOffset;
								tb.Content = GetConvolutionalLayerWeightsBitmap(layer, designPVM.Inverted);
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								scr.ScrollToHorizontalOffset(ho);
								scr.ScrollToVerticalOffset(vo);
								break;

                            case LayerTypes.LocalContrastNormalization:
                            case LayerTypes.LocalResponseNormalization:
                            case LayerTypes.LocalResponseNormalizationCM:
                                designPVM.TabItems[index].Content = GetWeightlessNormalizationLayerWeightsBitmap(layer);
                                break;

							case LayerTypes.MaxPoolingWeightless:
							case LayerTypes.AvgPoolingWeightless:
							case LayerTypes.StochasticPooling:
							case LayerTypes.L2Pooling:
								designPVM.TabItems[index].Content = GetWeightlessPoolingLayerWeightsBitmap(layer);
								break;

							case LayerTypes.AvgPooling:
							case LayerTypes.MaxPooling:
								tb = designPVM.TabItems[index];
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								ho = scr.HorizontalOffset;
								vo = scr.VerticalOffset;
								tb.Content = GetPoolingLayerWeightsBitmap(layer, designPVM.Inverted);
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								scr.ScrollToHorizontalOffset(ho);
								scr.ScrollToVerticalOffset(vo);
								break;

							case LayerTypes.FullyConnected:
								tb = designPVM.TabItems[index];
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								ho = scr.HorizontalOffset;
								vo = scr.VerticalOffset;
								tb.Content = GetFullyConnectedLayerWeightsBitmap(layer, designPVM.Inverted);
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								scr.ScrollToHorizontalOffset(ho);
								scr.ScrollToVerticalOffset(vo);
								break;

							case LayerTypes.RBF:
								tb = designPVM.TabItems[index];
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								ho = scr.HorizontalOffset;
								vo = scr.VerticalOffset;
								tb.Content = GetRBFLayerWeightsBitmap(layer, designPVM.Inverted);
								grid = tb.Content as Grid;
								scr = grid.Children[1] as ScrollViewer;
								scr.ScrollToHorizontalOffset(ho);
								scr.ScrollToVerticalOffset(vo);
								break;
						}
					}
					designPVM.SelectedLayerIndex = selectedIndex;
					needRefreshWeightsView = false;
				}
				else
				{
					designPVM.TabItems = new ObservableCollection<TabItem>();

					TabItem tb = null;
					foreach (Layer layer in pageViewModel.NeuralNetwork.Layers.Skip(1))
					{
						tb = new TabItem();
						tb.UseLayoutRounding = true;
						tb.SnapsToDevicePixels = true;
						tb.Header = layer.LayerIndex.ToString();
						designPVM.TabItems.Add(tb);
					}

					selectedIndex = 0;

					foreach (Layer layer in pageViewModel.NeuralNetwork.Layers.Skip(1))
					{
						int index = layer.LayerIndex - 1;

						switch (layer.LayerType)
						{
							case LayerTypes.Local:
								designPVM.TabItems[index].Content = GetLocalLayerWeightsBitmap(layer, designPVM.Inverted);
								break;

							case LayerTypes.Convolutional:
							case LayerTypes.ConvolutionalSubsampling:
								designPVM.TabItems[index].Content = GetConvolutionalLayerWeightsBitmap(layer, designPVM.Inverted);
								break;

                            case LayerTypes.LocalContrastNormalization:
                            case LayerTypes.LocalResponseNormalization:
                            case LayerTypes.LocalResponseNormalizationCM:
                                designPVM.TabItems[index].Content = GetWeightlessNormalizationLayerWeightsBitmap(layer);
                                break;

							case LayerTypes.MaxPoolingWeightless:
							case LayerTypes.AvgPoolingWeightless:
							case LayerTypes.StochasticPooling:
							case LayerTypes.L2Pooling:
								designPVM.TabItems[index].Content = GetWeightlessPoolingLayerWeightsBitmap(layer);
								break;

							case LayerTypes.AvgPooling:
							case LayerTypes.MaxPooling:
								designPVM.TabItems[index].Content = GetPoolingLayerWeightsBitmap(layer, designPVM.Inverted);
								break;

							case LayerTypes.FullyConnected:
								designPVM.TabItems[index].Content = GetFullyConnectedLayerWeightsBitmap(layer, designPVM.Inverted);
								break;

							case LayerTypes.RBF:
								designPVM.TabItems[index].Content = GetRBFLayerWeightsBitmap(layer, designPVM.Inverted);
								break;
						}
					}

					designPVM.SelectedLayerIndex = selectedIndex;
					needRefreshWeightsView = false;
				}
			}
		}

		private void OnViewModelStart(object sender, EventArgs e)
		{
			if (pageViewModel.CurrentContext == ContextTypes.Training)
			{
				if (pageViewModel.NeuralNetwork.CurrentTaskState == TaskState.Stopped)
				{
					TrainingRate rate = new TrainingRate();
					TrainingParameters dialog = new TrainingParameters();
					dialog.Owner = Application.Current.MainWindow;
					dialog.Path = TrainingParametersDirectory;
					dialog.buttonTrain.IsEnabled = true;
					dialog.Data = rate;
					dialog.pageViewModel = pageViewModel;
					if (dialog.ShowDialog() ?? false)
						StartTraining();
				}
				else
				{
					pageViewModel.NeuralNetwork.CurrentTaskState = TaskState.Running;
					pageViewModel.CommandToolBar[0].Visibility = Visibility.Collapsed;
					pageViewModel.CommandToolBar[0].ToolTip = "Start Training";
					pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
					pageViewModel.CommandToolBar[2].Visibility = Visibility.Visible;
					pageViewModel.CommandToolBar[5].IsEnabled = false;
				}
			}
			else
			{
				if (pageViewModel.NeuralNetwork.CurrentTaskState == TaskState.Stopped)
					StartTesting();
				else
				{
					pageViewModel.NeuralNetwork.CurrentTaskState = TaskState.Running;
					pageViewModel.CommandToolBar[0].Visibility = Visibility.Collapsed;
					pageViewModel.CommandToolBar[0].ToolTip = "Start Testing";
					pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
					pageViewModel.CommandToolBar[2].Visibility = Visibility.Visible;
				}
			}
		}

		private void OnViewModelStop(object sender, EventArgs e)
		{
			if (pageViewModel.CurrentContext == ContextTypes.Training)
			{
				TaskDialogOptions config = new TaskDialogOptions();
				config.Owner = Application.Current.MainWindow;
				config.MainIcon = VistaTaskDialogIcon.None;
				config.MainInstruction = "Do you really want to quit training ?";
				config.Title = "Quit training";
				config.CustomButtons = new string[] { "&Yes", "&No" };
				config.DefaultButtonIndex = 1;
				config.AllowDialogCancellation = false;

				if (TaskDialog.Show(config).CustomButtonResult == 0)
					StopTraining();
			}
			else
				StopTesting();
		}

		private void OnViewModelPause(object sender, EventArgs e)
		{
			if (pageViewModel.CurrentContext == ContextTypes.Training)
			{
				pageViewModel.NeuralNetwork.CurrentTaskState = TaskState.Paused;
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[0].ToolTip = "Resume Training";
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Collapsed;
			}
			else
			{
				pageViewModel.NeuralNetwork.CurrentTaskState = TaskState.Paused;
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[0].ToolTip = "Resume Testing";
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Collapsed;
			}
		}

		private void OnViewModelCalculate(object sender, EventArgs e)
		{
			StringBuilder sb = new StringBuilder();

			calculatePVM.IsValid = false;
			pageViewModel.CommandToolBar[0].IsEnabled = false;
			Mouse.OverrideCursor = Cursors.Wait;
			MainView.Status.Text = "Calculating...";

            if (!Properties.Settings.Default.AutoCalculate) 
                OnSampleIndexChanged(null, EventArgs.Empty);
			
            if (pageViewModel.NeuralNetwork.SubstractMean)
            {
                double[] data = pageViewModel.NeuralNetwork.CurrentSample.SubstractMean(DataProvider);
                for (int i = 0; i < DataProvider.SampleSize * DataProvider.SampleChannels; i++)
                    pageViewModel.NeuralNetwork.Layers[0].Neurons[i].Output = data[i];
            }
            else
                for (int i = 0; i < DataProvider.SampleSize * DataProvider.SampleChannels; i++)
                    pageViewModel.NeuralNetwork.Layers[0].Neurons[i].Output = (((double)pageViewModel.NeuralNetwork.CurrentSample.Image[i] / 255D) * pageViewModel.NeuralNetwork.Spread) + pageViewModel.NeuralNetwork.Min;

			System.Diagnostics.Stopwatch timer = new Stopwatch();
			timer.Restart();
			pageViewModel.NeuralNetwork.Calculate();
			int bestIndex = pageViewModel.NeuralNetwork.Recognized();
			double patternLoss = pageViewModel.NeuralNetwork.GetSampleLoss(pageViewModel.NeuralNetwork.CurrentSample.Label);
			timer.Stop();
          
            switch (pageViewModel.DataProvider.CurrentDataSet)
            {
                case DataProviderSets.MNIST:
                    for (int i = 0; i < pageViewModel.NeuralNetwork.LastLayer.NeuronCount; i++)
                        sb.AppendLine(i.ToString() + " \t\t= " + pageViewModel.NeuralNetwork.LastLayer.Neurons[i].Output.ToString(" 0.###################;-0.###################", CultureInfo.CurrentUICulture));
                    sb.AppendLine("\r\nSample loss: " + patternLoss.ToString("N17", CultureInfo.CurrentUICulture));
                    sb.AppendLine("Highest probability: " + bestIndex.ToString());
                    break;

                case DataProviderSets.CIFAR10:
                    CIFAR10Classes label;
                    for (int i = 0; i < pageViewModel.NeuralNetwork.ClassCount; i++)
                    {
                        label = (CIFAR10Classes)i;
                        if (label.ToString().Length <= 5)
                            sb.AppendFormat(CultureInfo.CurrentUICulture, "{0} \t\t= {1}\r\n", label, pageViewModel.NeuralNetwork.LastLayer.Neurons[i].Output.ToString(" 0.###################;-0.###################", CultureInfo.CurrentUICulture));
                        else
                            sb.AppendFormat(CultureInfo.CurrentUICulture, "{0} \t= {1}\r\n", label, pageViewModel.NeuralNetwork.LastLayer.Neurons[i].Output.ToString(" 0.###################;-0.###################", CultureInfo.CurrentUICulture));
                    }
                    sb.AppendLine("\r\nSample loss: " + patternLoss.ToString("N17", CultureInfo.CurrentUICulture));
                    sb.AppendLine("Highest probability: " + ((CIFAR10Classes)bestIndex).ToString());
                    break;
            }

            if (bestIndex == pageViewModel.NeuralNetwork.CurrentSample.Label)
                sb.AppendLine("Correctly recognized");
            else
                sb.AppendLine("Not correctly recognized");

            sb.AppendFormat("Time: {0} ms.", timer.ElapsedMilliseconds);
			calculatePVM.Result = sb.ToString();
			if (calculatePVM.Result.Length > 0)
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
			else
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;

			ShowCalculateOutput();

			Mouse.OverrideCursor = null;

			MainView.Status.Text = "Ready";

			calculatePVM.IsValid = true;
			MainView.PageContentControl.Focus();
			pageViewModel.CommandToolBar[0].IsEnabled = true;
		}

		private void ShowCalculateOutput()
		{
			int currentSelectedTabIndex = 0;
			if (calculatePVM.TabItems != null)
			{
				currentSelectedTabIndex = calculatePVM.SelectedTabIndex;
				int idx = 0;
				foreach (Layer layer in pageViewModel.NeuralNetwork.Layers)
				{
					if (layer.UseMapInfo)
					{
						TabItem tb = calculatePVM.TabItems[idx++];
						Grid grid = tb.Content as Grid;
						ScrollViewer scr = grid.Children[1] as ScrollViewer;
						double ho = scr.HorizontalOffset;
						double vo = scr.VerticalOffset;
						tb.Content = GetMappedLayerOutputsBitmap(layer, calculatePVM.Inverted);
						grid = tb.Content as Grid;
						scr = grid.Children[1] as ScrollViewer;
						scr.ScrollToHorizontalOffset(ho);
						scr.ScrollToVerticalOffset(vo);
					}
					else
					{
						TabItem tb = calculatePVM.TabItems[idx++];
						Grid grid = tb.Content as Grid;
						ScrollViewer scr = grid.Children[1] as ScrollViewer;
						double ho = scr.HorizontalOffset;
						double vo = scr.VerticalOffset;
						tb.Content = GetLayerOutputsBitmap(layer, calculatePVM.Inverted);
						grid = tb.Content as Grid;
						scr = grid.Children[1] as ScrollViewer;
						scr.ScrollToHorizontalOffset(ho);
						scr.ScrollToVerticalOffset(vo);
					}
				}
			}
			else
			{
				calculatePVM.TabItems = new ObservableCollection<TabItem>();

				foreach (Layer layer in pageViewModel.NeuralNetwork.Layers)
				{
					if (layer.UseMapInfo)
					{
						TabItem tb = new TabItem();
						tb.UseLayoutRounding = true;
						tb.SnapsToDevicePixels = true;
						tb.Header = layer.LayerIndex.ToString();
						tb.Content = GetMappedLayerOutputsBitmap(layer, calculatePVM.Inverted);
						calculatePVM.TabItems.Add(tb);
					}
					else
					{
						TabItem tb = new TabItem();
						tb.UseLayoutRounding = true;
						tb.SnapsToDevicePixels = true;
						tb.Header = layer.LayerIndex.ToString();
						tb.Content = GetLayerOutputsBitmap(layer, calculatePVM.Inverted);
						calculatePVM.TabItems.Add(tb);
					}
				}
			}

			int tab = currentSelectedTabIndex == -1 ? 0 : currentSelectedTabIndex;
			calculatePVM.SelectedTabIndex = tab;
			calculatePVM.TabItems[tab].IsSelected = true;
		}

		private void OnViewModelRefresh(object sender, EventArgs e)
		{
			if (pageViewModel.CurrentContext == ContextTypes.Design)
			{
				if (needRefreshWeightsView)
					RefreshWeightsView();   
			}
			else
				OnSampleIndexChanged(sender, e);
		}

		private void OnViewModelInvert(object sender, EventArgs e)
		{
			if (pageViewModel.CurrentContext == ContextTypes.Design)
			{
				designPVM.Inverted = !designPVM.Inverted;
				RefreshWeightsView();
			}
			else
			{
				if (calculatePVM.Result.Length > 0)
				{
					calculatePVM.Inverted = !calculatePVM.Inverted;
					ShowCalculateOutput();
				}
			}
		}

		private void OnViewModelForget(object sender, EventArgs e)
		{
			TaskDialogOptions config = new TaskDialogOptions();
			config.Owner = this;
			config.MainIcon = VistaTaskDialogIcon.None;
			config.MainInstruction = "Do you really want to forget all the weights ?";
			config.Title = "Forget learned weights";
			config.CustomButtons = new string[] { "&Yes", "&No" };
			config.DefaultButtonIndex = 1;
			config.AllowDialogCancellation = false;
			
			if (TaskDialog.Show(config).CustomButtonResult == 0)
			{
				Mouse.OverrideCursor = Cursors.Wait;
				trainingPVM.IsValid = false;
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[3].Visibility = Visibility.Collapsed;
				pageViewModel.NeuralNetwork.InitializeWeights();
				trainingPVM.TrainingResultCollection.Clear();
				needRefreshWeightsView = true;
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[3].Visibility = Visibility.Visible;
				trainingPVM.IsValid = true;
				Mouse.OverrideCursor = null;
			}
		}

		private void OnSampleIndexChanged(object sender, EventArgs e)
		{
			if (calculatePVM.SampleIndex >= 0)
			{
				ImageData sample;

				if (calculatePVM.UseTrainingSet)
					sample = calculatePVM.DataProvider.TrainingSamples[calculatePVM.SampleIndex];
				else
					sample = calculatePVM.DataProvider.TestingSamples[calculatePVM.SampleIndex];

				if (calculatePVM.UseDistortions)
					pageViewModel.NeuralNetwork.CurrentSample = sample.Distorted(calculatePVM.DataProvider, calculatePVM.SeverityFactor, calculatePVM.MaxScaling, calculatePVM.MaxRotation, calculatePVM.ElasticSigma, calculatePVM.ElasticScaling);
				else
					pageViewModel.NeuralNetwork.CurrentSample = sample;

				calculatePVM.SampleImage = pageViewModel.NeuralNetwork.CurrentSample.GetBitmapSource(pageViewModel.DataProvider);
                switch(pageViewModel.NeuralNetwork.DataProviderSet)
                {
                    case DataProviderSets.CIFAR10:
                        calculatePVM.Label = ((CIFAR10Classes)pageViewModel.NeuralNetwork.CurrentSample.Label).ToString();
                        break;

                    case DataProviderSets.MNIST:
                        calculatePVM.Label = pageViewModel.NeuralNetwork.CurrentSample.Label.ToString();
                        break;
                }

                if (Properties.Settings.Default.AutoCalculate)
                    OnViewModelCalculate(null, e);
			}
		}

		private void OnViewModelUseDistortionsChanged(object sender, EventArgs e)
		{
			if (calculatePVM.UseDistortions)
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
			else
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
		}

		private void OnViewModelUseTrainingSetChanged(object sender, EventArgs e)
		{
			OnSampleIndexChanged(sender, e);
		}

		private void OnViewModelEditor(object sender, EventArgs e)
		{
			TrainingRate rate = new TrainingRate();
			
			if (pageViewModel.CurrentContext == ContextTypes.Training)
			{
				if (pageViewModel.NeuralNetwork.CurrentTaskState == TaskState.Stopped)
				{
					TrainingSchemeEditor dialog = new TrainingSchemeEditor();
					dialog.Owner = Application.Current.MainWindow;
					dialog.Path = TrainingSchemesDirectory;
					dialog.Rate = rate;
					dialog.buttonTrain.IsEnabled = true;
					dialog.pageViewModel = pageViewModel;
					if (dialog.ShowDialog() ?? false)
						StartTraining();
				}
				else
				{
					TrainingSchemeEditor dialog = new TrainingSchemeEditor();
					dialog.Owner = Application.Current.MainWindow;
					dialog.Path = TrainingSchemesDirectory;
					dialog.Rate = rate;
					dialog.buttonTrain.IsEnabled = false;
					dialog.pageViewModel = pageViewModel;
					dialog.ShowDialog();
				}
			}
		}

		private void HandleDataProgressEvent(object sender, DataProviderEventArgs e)
		{
			Mouse.OverrideCursor = Cursors.Wait;
			taskBarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.Normal;
			taskBarItemInfo.ProgressValue = (double)e.Result * 0.01D;
		   
			MainView.ProgressBar.Minimum = 0D;
			MainView.ProgressBar.Maximum = 100D;
			MainView.ProgressBar.Value = e.Result;
			MainView.Status.Text = e.Message;
		}

		private void HandleDataLoadedEvent(object sender, DataProviderEventArgs e)
		{
			pageViewModel.DataProvider.RaiseDataProgressEvent -= HandleDataProgressEvent;
			pageViewModel.DataProvider.RaiseDataLoadedEvent -= HandleDataLoadedEvent;
			if (cleanUpViews)
				CleanUpViews();
			
			taskBarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
			MainView.ProgressBar.Value = 0;
			MainView.Status.Text = "Ready";
			MainView.Time.Text = "";
			MainView.SampleRate.Text = "";
			Mouse.OverrideCursor = null;
			MainView.PageViews.IsEnabled = true;
		}
		
		private void CleanUpViews()
		{
			pageViewModel.Reset();

			needRefreshWeightsView = true;
			if (pageViewModel.CurrentContext == ContextTypes.Design)
				RefreshWeightsView();

			GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
			GC.WaitForPendingFinalizers();
			GC.Collect();
		}

		private void NetworkProgressEvent(object sender, EventArgs e)
		{
			MainView.Time.Text = pageViewModel.NeuralNetwork.GetTaskDuration();
			MainView.SampleRate.Text = pageViewModel.NeuralNetwork.SampleRate.ToString("N2");
			MainView.CpuUsage.Text = cpu_using.NextValue().ToString("N2");
			taskBarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.Normal;
			
			switch (pageViewModel.NeuralNetwork.OperationState)
			{
				case NetworkStates.CalculatingHessian:
					taskBarItemInfo.ProgressValue = (double)(pageViewModel.NeuralNetwork.SampleIndex + 1) / pageViewModel.NeuralNetwork.HessianSamples;
					MainView.ProgressBar.Maximum = pageViewModel.NeuralNetwork.HessianSamples;
					MainView.ProgressBar.Value = pageViewModel.NeuralNetwork.SampleIndex;
					progressText.Length = 0;
					progressText.Append("Calculating Pseudo-Hessian...");
					trainingPVM.ProgressText = progressText.ToString();
					trainingPVM.SampleLabel = String.Empty;
					break;

				case NetworkStates.Training:
					taskBarItemInfo.ProgressValue = (double)(pageViewModel.NeuralNetwork.SampleIndex + 1) / pageViewModel.DataProvider.TrainingSamplesCount;
					MainView.ProgressBar.Maximum = pageViewModel.DataProvider.TrainingSamplesCount;
					MainView.ProgressBar.Value = pageViewModel.NeuralNetwork.SampleIndex;
					progressText.Length = 0;
					progressText.AppendFormat(CultureInfo.CurrentUICulture, ((pageViewModel.NeuralNetwork.TrainingRate.Distorted) ? ("Distorted:\t"+ pageViewModel.NeuralNetwork.TrainingRate.DistortionPercentage.ToString() + " %") : ("Not Distorted")) + "\nEpoch:\t\t{0:G}/{1:G}\nSample Index:\t{2:G}\nTraining Rate:\t{3:N10}\nAverage Loss:\t{4:N10}\nTrain Error %:\t{5:N4}\nTrain Errors:\t{6:G}", pageViewModel.NeuralNetwork.CurrentEpoch, pageViewModel.NeuralNetwork.TotalEpochs, pageViewModel.NeuralNetwork.SampleIndex, pageViewModel.NeuralNetwork.TrainingRate.Rate, pageViewModel.NeuralNetwork.AvgTrainLoss, ((double)pageViewModel.NeuralNetwork.TrainErrors * (100D / (pageViewModel.NeuralNetwork.SampleIndex + 1))), pageViewModel.NeuralNetwork.TrainErrors);
					trainingPVM.ProgressText = progressText.ToString();
					trainingPVM.SampleImage = pageViewModel.DataProvider.TrainingSamples[DataProvider.RandomTrainingSample[pageViewModel.NeuralNetwork.SampleIndex]].GetBitmapSource(pageViewModel.DataProvider);
					if (pageViewModel.NeuralNetwork.SampleIndex < pageViewModel.DataProvider.TrainingSamplesCount)
						if (trainingPVM.DataProvider.CurrentDataSet == DataProviderSets.CIFAR10)
							trainingPVM.SampleLabel = ((CIFAR10Classes)pageViewModel.DataProvider.TrainingSamples[DataProvider.RandomTrainingSample[pageViewModel.NeuralNetwork.SampleIndex]].Label).ToString();
						else
							trainingPVM.SampleLabel = pageViewModel.DataProvider.TrainingSamples[DataProvider.RandomTrainingSample[pageViewModel.NeuralNetwork.SampleIndex]].Label.ToString();
					break;

				case NetworkStates.Testing:
					if (testingPVM.UseTrainingSet)
					{
						taskBarItemInfo.ProgressValue = (double)(pageViewModel.NeuralNetwork.SampleIndex + 1) / pageViewModel.DataProvider.TrainingSamplesCount;
						MainView.ProgressBar.Maximum = pageViewModel.DataProvider.TrainingSamplesCount;
						if (pageViewModel.NeuralNetwork.SampleIndex < pageViewModel.DataProvider.TrainingSamplesCount)
							testingPVM.SampleImage = pageViewModel.DataProvider.TrainingSamples[pageViewModel.NeuralNetwork.SampleIndex].GetBitmapSource(pageViewModel.DataProvider);
					}
					else
					{
						taskBarItemInfo.ProgressValue = (double)(pageViewModel.NeuralNetwork.SampleIndex + 1) / pageViewModel.DataProvider.TestingSamplesCount;
						MainView.ProgressBar.Maximum = pageViewModel.DataProvider.TestingSamplesCount;
						if (pageViewModel.NeuralNetwork.SampleIndex < pageViewModel.DataProvider.TestingSamplesCount)
							testingPVM.SampleImage = pageViewModel.DataProvider.TestingSamples[pageViewModel.NeuralNetwork.SampleIndex].GetBitmapSource(pageViewModel.DataProvider);
					}
					MainView.ProgressBar.Value = pageViewModel.NeuralNetwork.SampleIndex;
					progressText.Length = 0;
					{
						double testAccuracy = (double)((pageViewModel.NeuralNetwork.SampleIndex + 1) - pageViewModel.NeuralNetwork.TestErrors) * (100D / (pageViewModel.NeuralNetwork.SampleIndex + 1));
						progressText.AppendFormat(CultureInfo.CurrentUICulture, "\nSample Index:\t{0:G}\nAverage Loss:\t{1:N10}\nTest Error %:\t{2:N4}\nTest Errors:\t{3:G}\nAccuracy %:\t{4:N4}", pageViewModel.NeuralNetwork.SampleIndex, pageViewModel.NeuralNetwork.AvgTestLoss, 100D - testAccuracy, pageViewModel.NeuralNetwork.TestErrors, testAccuracy);
						testingPVM.ProgressText = progressText.ToString();
						if (testingPVM.DataProvider.CurrentDataSet == DataProviderSets.CIFAR10)
							testingPVM.SampleLabel = ((CIFAR10Classes)pageViewModel.NeuralNetwork.CurrentSample.Label).ToString();
						else
							testingPVM.SampleLabel = pageViewModel.NeuralNetwork.CurrentSample.Label.ToString();
					}
					break;

				case NetworkStates.CalculatingTestError:
					taskBarItemInfo.ProgressValue = (double)(pageViewModel.NeuralNetwork.SampleIndex + 1) / pageViewModel.DataProvider.TestingSamplesCount;
					MainView.ProgressBar.Maximum = pageViewModel.DataProvider.TestingSamplesCount;
					MainView.ProgressBar.Value = pageViewModel.NeuralNetwork.SampleIndex;
					trainingPVM.SampleImage = null;
					progressText.Length = 0;
					progressText.Append("Calculating Test Error...");
					{
						double testAccuracy = ((pageViewModel.NeuralNetwork.SampleIndex + 1) - pageViewModel.NeuralNetwork.TestErrors) * (100D / (pageViewModel.NeuralNetwork.SampleIndex + 1));
						progressText.AppendFormat(CultureInfo.CurrentUICulture, "\n\nSample Index:\t{0:G}\nAverage Loss:\t{1:N10}\nTest Error %:\t{2:N4}\nTest Errors:\t{3:G}\nAccuracy %:\t{4:N4}", pageViewModel.NeuralNetwork.SampleIndex, pageViewModel.NeuralNetwork.AvgTestLoss, 100D - testAccuracy, pageViewModel.NeuralNetwork.TestErrors, testAccuracy);
					}
					trainingPVM.ProgressText = progressText.ToString();
					trainingPVM.SampleLabel = String.Empty;
					break;

				case NetworkStates.SavingWeights:
					MainView.SampleRate.Text = String.Empty;
					taskBarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
					MainView.ProgressBar.Value = 0;
					progressText.Length = 0;
					progressText.Append("Saving Weights...");
					trainingPVM.ProgressText = progressText.ToString();
					trainingPVM.SampleLabel = String.Empty;
					break;

				case NetworkStates.NewEpoch:
					MainView.SampleRate.Text = String.Empty;
					trainingPVM.SampleImage = null;
					trainingPVM.SampleLabel = String.Empty;
					TimeSpan span = pageViewModel.NeuralNetwork.TaskDuration.Elapsed.Subtract(pageViewModel.NeuralNetwork.EpochDuration);
					pageViewModel.NeuralNetwork.EpochDuration = pageViewModel.NeuralNetwork.TaskDuration.Elapsed;
					{
						double testAccuracy = (pageViewModel.DataProvider.TestingSamplesCount - pageViewModel.NeuralNetwork.TestErrors) * (100D / pageViewModel.DataProvider.TestingSamplesCount);
						trainingPVM.TrainingResultCollection.Add(new TrainingResult(pageViewModel.NeuralNetwork.CurrentEpoch, pageViewModel.NeuralNetwork.TrainingRate.Distorted ? pageViewModel.NeuralNetwork.TrainingRate.DistortionPercentage : 0, pageViewModel.NeuralNetwork.TrainingRate.Rate, pageViewModel.NeuralNetwork.AvgTrainLoss, pageViewModel.NeuralNetwork.TrainErrors, (double)pageViewModel.NeuralNetwork.TrainErrors * (100D / pageViewModel.DataProvider.TrainingSamplesCount), pageViewModel.NeuralNetwork.AvgTestLoss, pageViewModel.NeuralNetwork.TestErrors, 100D - testAccuracy, testAccuracy, new TimeSpan(span.Hours, span.Minutes, span.Seconds)));
					}
					trainingPVM.SelectedIndex = trainingPVM.TrainingResultCollection.Count - 1;
					pageViewModel.NeuralNetwork.OperationState = NetworkStates.Idle;
					break;
			}

			if (pageViewModel.NeuralNetwork.CurrentTaskState == TaskState.Stopped)
			{
				MainView.SampleRate.Text = String.Empty;
				taskBarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
				
				pageViewModel.NeuralNetwork.CurrentTaskState = TaskState.Running;
				if (pageViewModel.NeuralNetwork.OperationState == NetworkStates.Testing)
				{
					testingPVM.SampleLabel = String.Empty;
					testingPVM.SampleImage = null;
					StopTesting();
				}
				else
				{
					trainingPVM.SampleLabel = String.Empty;
					trainingPVM.SampleImage = null;
					StopTraining();
				}
			}
		}

		private void AddUnrecognizedTestSampleEvent(object sender, AddUnrecognizedTestSampleEventArgs e)
		{
			testingPVM.ConfusionMatrix[e.Sample.Label].Items.Add(new ConfusedItem(e.SampleIndex, e.WrongValue, e.Sample, pageViewModel.DataProvider));
			testingPVM.ConfusionMatrix[e.Sample.Label].IsSelected = true;
			testingPVM.ConfusionMatrix[e.Sample.Label].Focus();
		}

		private void StartTraining()
		{
			if (pageViewModel.NeuralNetwork.CurrentTaskState == TaskState.Stopped)
			{
				Mouse.OverrideCursor = Cursors.Wait;
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[4].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[5].IsEnabled = false;
			   
				trainingPVM.IsValid = false;
				needRefreshWeightsView = true;

				pageViewModel.NeuralNetwork.StartTraining();
				MainView.Status.Text = String.Empty;

				pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Visible;
				Mouse.OverrideCursor = null;
			}
		}

		private void StopTraining()
		{
			if (pageViewModel.NeuralNetwork.CurrentTaskState != TaskState.Stopped)
			{
				Mouse.OverrideCursor = Cursors.Wait;
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Collapsed;

				pageViewModel.NeuralNetwork.StopTraining();

				MainView.Status.Text = "Ready";
				trainingPVM.SampleLabel = String.Empty;
				trainingPVM.SampleImage  = null;
				MainView.ProgressBar.Value = 0;
				MainView.CpuUsage.Text = String.Empty;
				MainView.SampleRate.Text = String.Empty;
				trainingPVM.ProgressText = String.Empty;
				MainView.Time.Text = String.Empty;

				taskBarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
				pageViewModel.CommandToolBar[0].ToolTip = "Start Training";
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[4].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[5].IsEnabled = true;
				trainingPVM.IsValid = true;
				Mouse.OverrideCursor = null;
			}
		}

		private void StartTesting()
		{
			if (pageViewModel.NeuralNetwork.CurrentTaskState == TaskState.Stopped)
			{
				Mouse.OverrideCursor = Cursors.Wait;
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Collapsed;
				
				testingPVM.IsValid = false;
				MainView.Status.Text = String.Empty;
				testingPVM.ConfusionDocument = String.Empty;
				testingPVM.ConfusionMatrix = new ConfusionMatrix("ConfusionMatrix", testingPVM.DataProvider);

				pageViewModel.NeuralNetwork.TestParameters = new TestingParameters(testingPVM.UseTrainingSet, testingPVM.UseDistortions, testingPVM.UseDistortions ? 100 : 0, testingPVM.SeverityFactor, testingPVM.MaxScaling, testingPVM.MaxRotation, testingPVM.ElasticSigma, testingPVM.ElasticScaling);
				pageViewModel.NeuralNetwork.StartTesting();

				pageViewModel.CommandToolBar[1].Visibility = Visibility.Visible;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Visible;
				Mouse.OverrideCursor = null;
			}
		}

		private void StopTesting()
		{
			if (pageViewModel.NeuralNetwork.CurrentTaskState != TaskState.Stopped)
			{
				Mouse.OverrideCursor = Cursors.Wait;
				pageViewModel.CommandToolBar[1].Visibility = Visibility.Collapsed;
				pageViewModel.CommandToolBar[2].Visibility = Visibility.Collapsed;

				pageViewModel.NeuralNetwork.StopTesting();
				
				taskBarItemInfo.ProgressState = System.Windows.Shell.TaskbarItemProgressState.None;
				MainView.ProgressBar.Value = 0;
				int total = 0;
			  
				testingPVM.ConfusionDocument = String.Empty;
				StringBuilder sb = new StringBuilder();
				switch (testingPVM.DataProvider.CurrentDataSet)
				{
					case DataProviderSets.CIFAR10:
						foreach (ConfusionItems wrong in testingPVM.ConfusionMatrix)
						{
							if (wrong != null)
							{
								CIFAR10Classes label = (CIFAR10Classes)wrong.CorrectValue;
								total += wrong.Items.Count;

								if (testingPVM.UseTrainingSet)
									sb.AppendFormat("{0} ({1} incorrect)\r\n==================\r\n", label.ToString(), wrong.Items.Count);
								else
									sb.AppendFormat("{0} ({1} incorrect)\r\n=================\r\n", label.ToString(), wrong.Items.Count);
								foreach (ConfusedItem wrongImage in wrong.Items)
								{
									CIFAR10Classes wrongLabel = (CIFAR10Classes)wrongImage.WrongValue;

									if (wrongImage != null)
										sb.AppendFormat("{0:D4} as {1}\r\n", wrongImage.SampleIndex, wrongLabel.ToString());
								}
							}
							sb.Append("\r\n");
						}
						break;

					case DataProviderSets.MNIST:
						foreach (ConfusionItems wrong in testingPVM.ConfusionMatrix)
						{
							if (wrong != null)
							{
								total += wrong.Items.Count;
								if (testingPVM.UseTrainingSet)
									sb.AppendFormat("{0} ({1} incorrect)\r\n============\r\n", wrong.CorrectValue, wrong.Items.Count);
								else
									sb.AppendFormat("{0} ({1} incorrect)\r\n===========\r\n", wrong.CorrectValue, wrong.Items.Count);
								foreach (ConfusedItem wrongImage in wrong.Items)
								{
									if (wrongImage != null)
										sb.AppendFormat("{0:D4} as {1}\r\n", wrongImage.SampleIndex, wrongImage.WrongValue);
								}
							}
							sb.Append("\r\n");
						}
						break;
				}
				sb.AppendFormat("{0} samples not recognized", total);
				testingPVM.ConfusionDocument = sb.ToString();
				testingPVM.SelectedTabIndex = 0;

				pageViewModel.CommandToolBar[0].ToolTip = "Start Testing";
				pageViewModel.CommandToolBar[0].Visibility = Visibility.Visible;
				MainView.Time.Text = String.Empty;
				MainView.CpuUsage.Text = String.Empty;
				MainView.Status.Text = "Ready";
				testingPVM.IsValid = true;
				
				Mouse.OverrideCursor = null;
			}
		}

		#region "Menu handling not yet implemented"
		void PrintCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			//String command, targetobj;
			//command = ((RoutedCommand)e.Command).Name;
			//targetobj = ((FrameworkElement)target).Name;
			//TaskDialog.Show("The " + command + " command has been invoked on target object " + targetobj);
		}

		void PrintCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = false;
		}

		void PrintPreviewCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			//String command, targetobj;
			//command = ((RoutedCommand)e.Command).Name;
			//targetobj = ((FrameworkElement)target).Name;
			//TaskDialog.Show("The " + command + " command has been invoked on target object " + targetobj);
		}

		void PrintPreviewCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = false;
		}

		void PageSetupCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			//String command, targetobj;
			//command = ((RoutedCommand)e.Command).Name;
			//targetobj = ((FrameworkElement)target).Name;
			//TaskDialog.Show("The " + command + " command has been invoked on target object " + targetobj);
		}

		void PageSetupCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = false;
		}
		#endregion

		void CutCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			(e.Source as TextBox).Cut();
			e.Handled = true;
		}

		void CutCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			if (e.Source.GetType() == typeof(TextBox))
				e.CanExecute = (e.Source as TextBox).SelectionLength > 0;
			else
				e.CanExecute = false;
		}

		void CopyCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			(e.Source as TextBox).Copy();
			e.Handled = true;
		}

		void CopyCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			if (e.Source.GetType() == typeof(TextBox))
				e.CanExecute = (e.Source as TextBox).SelectionLength > 0;
			else
				e.CanExecute = false;
		}

		void PasteCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			(e.Source as TextBox).Paste();
			e.Handled = true;
		}

		void PasteCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = false;
		}

		void SelectAllCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			(e.Source as TextBox).SelectAll();
			e.Handled = true;
		}

		void SelectAllCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			if (e.Source.GetType() == typeof(TextBox))
				e.CanExecute = true;
			else
				e.CanExecute = false;
		}

		void UndoCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			e.Handled = (e.Source as TextBox).Undo();
		}

		void UndoCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			if (e.Source.GetType() == typeof(TextBox))
				e.CanExecute = (e.Source as TextBox).CanUndo;
			else
				e.CanExecute = false;
		}

		void RedoCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			e.Handled = (e.Source as TextBox).Redo();
		}

		void RedoCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			if (e.Source.GetType() == typeof(TextBox))
				e.CanExecute = (e.Source as TextBox).CanRedo;
			else
				e.CanExecute = false;
		}

		void HelpCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			System.Diagnostics.Process.Start("http://www.codeproject.com/KB/recipes/CNNWBMNIST.aspx");
			e.Handled = true;
		}

		void HelpCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = true;
		}

		void AboutCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			Window aboutDialog = new About();
			aboutDialog.Owner = this;
			aboutDialog.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterOwner;
			aboutDialog.ShowDialog();
			e.Handled = true;
		}

		void AboutCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = true;
		}
		
		void ApplicationExitCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			Application.Current.MainWindow.Close();
			e.Handled = true;
		}

		void ApplicationExitCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = true;
		}

		void OpenCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			openFileDialog = new Microsoft.Win32.OpenFileDialog();
			openFileDialog.CheckFileExists = true;
			openFileDialog.CheckPathExists = true;
			openFileDialog.Multiselect = false;
			openFileDialog.AddExtension = true;
			openFileDialog.ValidateNames = true;
			openFileDialog.Filter = "Xml Network Definition|*.definition-xml|Binary Network Weights|*.weights-bin|Fully Zipped Network and weights|*.zip|Old Xml binary Network Weights|*.weights-xml-bin";
			openFileDialog.Title = "Load neural network";
			openFileDialog.DefaultExt = ".weights-bin";
			openFileDialog.FilterIndex = 2;
			openFileDialog.InitialDirectory = StorageDirectory + @"\";
		   
			TaskDialogOptions config = new TaskDialogOptions();
			config.Owner = this;
			config.MainIcon = VistaTaskDialogIcon.Information;
			config.Title = "Information";
			config.CommandButtons = new string[] { "&OK" };
			config.AllowDialogCancellation = false;

			DataProviderSets oldSet = pageViewModel.NeuralNetwork.DataProviderSet;
			bool stop = false;
			do
			{
				bool? ret = openFileDialog.ShowDialog(this); //Application.Current.MainWindow);
				
				if (ret.HasValue && ret.GetValueOrDefault(false) == true)
				{
					Mouse.OverrideCursor = Cursors.Wait;
					string fileName = openFileDialog.FileName;

					if (fileName.Contains(".definition-xml"))
					{
						NeuralNetwork network = NeuralNetwork.LoadDefinition(fileName, DataProvider);
						if (network != null)
						{
							cleanUpViews = true;
							DataProvider.LoadDataset(network.DataProviderSet);
							network.RaiseNetworkProgressEvent += new EventHandler<EventArgs>(NetworkProgressEvent);
							network.RaiseAddUnrecognizedTestSampleEvent += new EventHandler<AddUnrecognizedTestSampleEventArgs>(AddUnrecognizedTestSampleEvent);
							pageViewModel.NeuralNetwork = network;
							Title = "Convolutional Neural Network Workbench - " + pageViewModel.NeuralNetwork.Name;
							stop = true;
							CleanUpViews();
							config.MainInstruction = "Neural network definition is loaded.";
							Mouse.OverrideCursor = null;
							TaskDialog.Show(config);
						}
						else
						{
							Mouse.OverrideCursor = null;
							config.MainInstruction = "Incompatible data format.";
							config.Title = "Choose an other file";
							TaskDialog.Show(config);
						}
					}
					
					if (fileName.Contains(".zip"))
					{
						NeuralNetwork network = NeuralNetwork.LoadFullyZipped(fileName, DataProvider);
						if (network != null)
						{
							cleanUpViews = true;
							DataProvider.LoadDataset(network.DataProviderSet);
							network.RaiseNetworkProgressEvent += new EventHandler<EventArgs>(NetworkProgressEvent);
							network.RaiseAddUnrecognizedTestSampleEvent += new EventHandler<AddUnrecognizedTestSampleEventArgs>(AddUnrecognizedTestSampleEvent);
							pageViewModel.NeuralNetwork = network;
							Title = "Convolutional Neural Network Workbench - " + pageViewModel.NeuralNetwork.Name;
							stop = true;
							CleanUpViews();
							config.MainInstruction = "Neural network definition and weights are loaded.";
							Mouse.OverrideCursor = null;
							TaskDialog.Show(config);
						}
						else
						{
							Mouse.OverrideCursor = null;
							config.MainInstruction = "Incompatible data format.";
							config.Title = "Choose an other file";
							TaskDialog.Show(config);
						}
					}
					   
					if (fileName.Contains(".weights-bin"))
					{
						if (pageViewModel.NeuralNetwork.LoadWeights(fileName))
						{
							needRefreshWeightsView = true;
							if (pageViewModel.CurrentContext == ContextTypes.Design)
								RefreshWeightsView();
							stop = true;

							config.MainInstruction = "Neural network weights are loaded.";
							Mouse.OverrideCursor = null;
							TaskDialog.Show(config);
						}
						else
						{
							Mouse.OverrideCursor = null;
							config.MainInstruction = "Incompatible data format.";
							config.Title = "Choose an other file";
							TaskDialog.Show(config);
						}
					}

					if (fileName.Contains(".weights-xml-bin") && fileName.Contains(pageViewModel.NeuralNetwork.Name))
					{
						if (pageViewModel.NeuralNetwork.LoadWeightsXmlBin(fileName))
						{
							needRefreshWeightsView = true;

							if (pageViewModel.CurrentContext == ContextTypes.Design)
								RefreshWeightsView();
							stop = true;

							config.MainInstruction = "Neural network weights are loaded.";
							Mouse.OverrideCursor = null;
							TaskDialog.Show(config);
						}
						else
						{
							Mouse.OverrideCursor = null;
							config.MainInstruction = "Incompatible data format.";
							config.Title = "Choose an other file";
							TaskDialog.Show(config);
						}
					}
							

					Mouse.OverrideCursor = null;
				}
				else
					stop = true;

			} while (!stop);

			Mouse.OverrideCursor = null;
			//e.Handled = true;
		}
        
		bool LoadDataset(DataProviderSets oldSet, DataProviderSets newSet)
		{
			if (newSet != oldSet)
			{
				Mouse.OverrideCursor = Cursors.Wait;
				MainView.PageViews.IsEnabled = false;
				
				cleanUpViews = true;
				pageViewModel.DataProvider.RaiseDataLoadedEvent += new EventHandler<DataProviderEventArgs>(HandleDataLoadedEvent);
				pageViewModel.DataProvider.RaiseDataProgressEvent += new EventHandler<DataProviderEventArgs>(HandleDataProgressEvent);
				pageViewModel.DataProvider.LoadDataset(newSet);

				return true;
			}

			return false;
		}

		void SaveCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			string filePath = StorageDirectory + @"\";
			
			if (File.Exists(filePath + pageViewModel.NeuralNetwork.Name + ".weights-bin"))
			{
				TaskDialogOptions options = new TaskDialogOptions();
				options.Owner = this;
				options.MainIcon = VistaTaskDialogIcon.None;
				options.MainInstruction = "Do you want to overwrite the existing file ?";
				options.Title = "File already exists";
				options.CustomButtons = new string[] { "&Yes", "&No" };
				options.DefaultButtonIndex = 1;
				options.AllowDialogCancellation = false;
				TaskDialogResult result = TaskDialog.Show(options);

				if (result.CustomButtonResult == 0)
					SaveWeights(filePath);
			}
			else
				SaveWeights(filePath);

			//e.Handled = true;
			Mouse.OverrideCursor = null;
		}

		private void SaveWeights(string filePath)
		{
			Mouse.OverrideCursor = Cursors.Wait;
			pageViewModel.NeuralNetwork.SaveWeights(filePath + pageViewModel.NeuralNetwork.Name + ".weights-bin");
			Mouse.OverrideCursor = null;
			TaskDialogOptions config = new TaskDialogOptions();
			config.Owner = this;
			config.MainIcon = VistaTaskDialogIcon.None;
			config.MainInstruction = "Neural network weights are saved.";
			config.Title = "Information";
			config.CommandButtons = new string[] { "&OK" };
			config.AllowDialogCancellation = false;
			TaskDialog.Show(config);
		}

		void SaveAsCmdExecuted(object target, ExecutedRoutedEventArgs e)
		{
			saveFileDialog = new Microsoft.Win32.SaveFileDialog();
			saveFileDialog.FileName = pageViewModel.NeuralNetwork.Name;
			saveFileDialog.AddExtension = true;
			saveFileDialog.CreatePrompt = false;
			saveFileDialog.OverwritePrompt = true;
			saveFileDialog.ValidateNames = true;
			saveFileDialog.Filter = "Xml Network Definition|*.definition-xml|Binary Network Weights|*.weights-bin|Fully Zipped Network and weights|*.zip";
			saveFileDialog.Title = "Save neural network";
			saveFileDialog.DefaultExt = ".weights-bin";
			saveFileDialog.FilterIndex = 2;
			saveFileDialog.InitialDirectory = StorageDirectory + @"\";

			TaskDialogOptions config = new TaskDialogOptions();
			config.Owner = this;
			config.MainIcon = VistaTaskDialogIcon.None;
			config.Title = "Information";
			config.CommandButtons = new string[] { "&OK" };
			config.AllowDialogCancellation = false;

			if (saveFileDialog.ShowDialog(this.Owner) == true)
			{
				string fileName = saveFileDialog.FileName;

				Mouse.OverrideCursor = Cursors.Wait;
				if (fileName.Contains(".definition-xml"))
				{
					pageViewModel.NeuralNetwork.SaveDefinition(fileName);
					Mouse.OverrideCursor = null;
					config.MainInstruction = "Neural network definition is saved.";
					TaskDialog.Show(config);
				}

				if (fileName.Contains(".weights-bin"))
				{
					pageViewModel.NeuralNetwork.SaveWeights(fileName);
					Mouse.OverrideCursor = null;
					config.MainInstruction = "Neural network weights are saved.";
					TaskDialog.Show(config);
				}

				if (fileName.Contains(".zip"))
				{
					pageViewModel.NeuralNetwork.SaveFullyZipped(fileName);
					Mouse.OverrideCursor = null;
					config.MainInstruction = "Neural network is saved.";
					TaskDialog.Show(config);
				}
			}
			Mouse.OverrideCursor = null;
			e.Handled = true;
		}

		void FileCommands(ref CanExecuteRoutedEventArgs e)
		{
			if (pageViewModel != null)
				e.CanExecute = pageViewModel.CurrentPage.IsValid;
			else
				e.CanExecute = false;
		 }

		void OpenCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			FileCommands(ref e);
		}

		void SaveCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			FileCommands(ref e);
            if ((trainingPVM != null) && (trainingPVM.NeuralNetwork.CurrentTaskState == TaskState.Paused))
                e.CanExecute = true;
		}

		void SaveAsCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
		{
			FileCommands(ref e);
            if ((trainingPVM != null) && (trainingPVM.NeuralNetwork.CurrentTaskState == TaskState.Paused))
                e.CanExecute = true;
		}

		private static double GetRangeFactor(double min, double max)
		{
			double range = 0D;

			if (Math.Sign(min) == Math.Sign(max))
			{
				if (Math.Sign(min) == -1) // both negative
					range = 255D / -(min + max);
				else // both positive
					range = 255D / (max - min);
			}
			else
				range = 255D / (max - min);

			return range;
		}

		private static byte GetColorFromRange(double range, double min, double value)
		{
			return (byte)(255D - ((value - min) * range));
		}

		private Grid GetPoolingLayerWeightsBitmap(Layer layer, bool inverted = false)
		{
			double weightMin = layer.Weights.Min(weight => weight.Value);
			double weightMax = layer.Weights.Max(weight => weight.Value);
			double range = GetRangeFactor(weightMin, weightMax);
			int end = layer.WeightCount / layer.NeuronCount;
			int width = (layer.MapCount * 2) + 1;
			int height = 5;
			int size = width * height;

			System.Windows.Controls.Image image = new System.Windows.Controls.Image();
			image.Stretch = Stretch.Uniform;
			image.StretchDirection = StretchDirection.Both;
			image.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
			image.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
			image.SnapsToDevicePixels = true;
			image.UseLayoutRounding = true;
			RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
			image.Width = width * Properties.Settings.Default.BlockSize;
			image.Height = height * Properties.Settings.Default.BlockSize;

			byte[] img = new byte[size];
			for (int i = 0; i < size; i++)
				img[i] = 255;

			if (inverted)
			{
				for (int map = 0; map < layer.MapCount; map++)
				{
					int xx = 1 + (map * 2);
					img[xx + (3 * width)] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[map * 2].Value));
					img[xx + width] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[(map * 2) + 1].Value));
				}
			}
			else
			{
				for (int map = 0; map < layer.MapCount; map++)
				{
					int xx = 1 + (map * 2);
					img[xx + (3 * width)] = GetColorFromRange(range, weightMin, layer.Weights[map * 2].Value);
					img[xx + width] = GetColorFromRange(range, weightMin, layer.Weights[(map * 2) + 1].Value);
				}
			}

			BitmapSource output = BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, img, width);
			if (output.CanFreeze)
				output.Freeze();

			image.Source = output;

			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			RowDefinition row = new RowDefinition();
			row.Height = new GridLength(50);
			grid.RowDefinitions.Add(row);
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");

			string tabMin = weightMin < 0 ? " " : "  ";
			string tabMax = weightMax < 0 ? " " : "  ";

			if (inverted)
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (black)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (white)";
			else
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (white)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (black)";

			ScrollViewer scr = new ScrollViewer();
			scr.SnapsToDevicePixels = true;
			scr.UseLayoutRounding = true;
			scr.CanContentScroll = true;
			scr.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			scr.VerticalContentAlignment = VerticalAlignment.Stretch;
			scr.VerticalAlignment = VerticalAlignment.Stretch;
			scr.HorizontalAlignment = HorizontalAlignment.Stretch;
			scr.Height = double.NaN;
			scr.Width = double.NaN;
			scr.Content = image;

			grid.Children.Add(block);
			grid.Children.Add(scr);
			Grid.SetRow(block, 0);
			Grid.SetRow(scr, 1);

			return grid;
		}

		private Grid GetFullyConnectedLayerWeightsBitmap(Layer layer, bool inverted = false)
		{
			double weightMin = layer.Weights.Min(weight => weight.Value);
			double weightMax = layer.Weights.Max(weight => weight.Value);
			double range = GetRangeFactor(weightMin, weightMax);
			int end = layer.WeightCount / layer.NeuronCount;
			int width = end + 3;
			int height = layer.NeuronCount + 2;
			int size = width * height;

			System.Windows.Controls.Image image = new System.Windows.Controls.Image();
			image.Stretch = Stretch.Uniform;
			image.StretchDirection = StretchDirection.Both;
			image.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
			image.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
			image.SnapsToDevicePixels = true;
			image.UseLayoutRounding = true;
			RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
			image.Width = width * Properties.Settings.Default.BlockSize;
			image.Height = height * Properties.Settings.Default.BlockSize;

			byte[] img = new byte[size];
			for (int i = 0; i < size; i++)
				img[i] = 255;

			if (inverted)
			{
				for (int neuron = 0; neuron < layer.NeuronCount; neuron++)
				{
					int y = 0;
					for (int r = neuron * end; r < (neuron + 1) * end; r++)
					{
						int xx;
						if ((y % end) == 0)
							xx = y+1;
						else
							xx = y+2;

						int yy = neuron + 1;
						img[xx + (yy * width)] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[r].Value));
						y++;
					}
				}
			}
			else
			{
				for (int neuron = 0; neuron < layer.NeuronCount; neuron++)
				{
					int y = 0;
					for (int r = neuron * end; r < (neuron + 1) * end; r++)
					{
						int xx;
						if ((y % end) == 0)
							xx = y+1;
						else
							xx = y+2;

						int yy = neuron + 1;
						img[xx + (yy * width)] = GetColorFromRange(range, weightMin, layer.Weights[r].Value);
						y++;
					}
				}
			}
			BitmapSource output = BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, img, width);
			if (output.CanFreeze)
				output.Freeze();

			image.Source = output;

			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			RowDefinition row = new RowDefinition();
			row.Height = new GridLength(50);
			grid.RowDefinitions.Add(row);
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");

			string tabMin = weightMin < 0 ? " " : "  ";
			string tabMax = weightMax < 0 ? " " : "  ";
			
			if (inverted)
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (white)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (black)";
			else
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (black)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (white)";

			ScrollViewer scr = new ScrollViewer();
			scr.SnapsToDevicePixels = true;
			scr.UseLayoutRounding = true;
			scr.CanContentScroll = true;
			scr.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			scr.VerticalContentAlignment = VerticalAlignment.Stretch;
			scr.VerticalAlignment = VerticalAlignment.Stretch;
			scr.HorizontalAlignment = HorizontalAlignment.Stretch;
			scr.Height = double.NaN;
			scr.Width = double.NaN;
			scr.Content = image;

			grid.Children.Add(block);
			grid.Children.Add(scr);
			Grid.SetRow(block, 0);
			Grid.SetRow(scr, 1);

			return grid;
		}

		private Grid GetRBFLayerWeightsBitmap(Layer layer, bool inverted = false)
		{
			double weightMin = layer.Weights.Min(weight => weight.Value);
			double weightMax = layer.Weights.Max(weight => weight.Value);
			double range = GetRangeFactor(weightMin, weightMax);
			int end = layer.WeightCount / layer.NeuronCount;
			int width = (layer.NeuronCount * layer.PreviousLayer.MapWidth) + (layer.NeuronCount);
			int height = layer.PreviousLayer.MapHeight + 2;
			int size = width * height;
			
			System.Windows.Controls.Image image = new System.Windows.Controls.Image();
			image.Stretch = Stretch.Uniform;
			image.StretchDirection = StretchDirection.Both;
			image.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
			image.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
			image.SnapsToDevicePixels = true;
			image.UseLayoutRounding = true;
			RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
			image.Width = width * Properties.Settings.Default.BlockSize;
			image.Height = height * Properties.Settings.Default.BlockSize;

			byte[] img = new byte[size];
			for (int i = 0; i < size; i++)
				img[i] = 255;

			if (inverted)
			{
				for (int neuron = 0; neuron < layer.NeuronCount; neuron++)
				{
					int index = 0;
					for (int y = 0; y < layer.PreviousLayer.MapHeight; y++)
						for (int x = 0; x < layer.PreviousLayer.MapWidth; x++)
						{
							index = x + (y * layer.PreviousLayer.MapWidth) + (neuron * layer.WeightCount / layer.NeuronCount);
							int xx = 1 + x + neuron + (neuron * layer.PreviousLayer.MapWidth);
							int yy = 1 + y;

							img[xx + (yy * width)] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[index].Value));
						}
				}
			}
			else
			{
				for (int neuron = 0; neuron < layer.NeuronCount; neuron++)
				{
					int index = 0;
					for (int y = 0; y < layer.PreviousLayer.MapHeight; y++)
						for (int x = 0; x < layer.PreviousLayer.MapWidth; x++)
						{
							index = x + (y * layer.PreviousLayer.MapWidth) + (neuron * layer.WeightCount / layer.NeuronCount);
							int xx = 1 + x + neuron + (neuron * layer.PreviousLayer.MapWidth);
							int yy = 1 + y;

							img[xx + (yy * width)] = GetColorFromRange(range, weightMin, layer.Weights[index].Value);
						}
				}
			}
			BitmapSource output = BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, img, width);
			if (output.CanFreeze)
				output.Freeze();
			image.Source = output;

			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			RowDefinition row = new RowDefinition();
			row.Height = new GridLength(50);
			grid.RowDefinitions.Add(row);
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");

			string tabMin = weightMin < 0 ? " " : "  ";
			string tabMax = weightMax < 0 ? " " : "  ";

			if (inverted)
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (white)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (black)";
			else
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (black)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (white)";

			ScrollViewer scr = new ScrollViewer();
			scr.SnapsToDevicePixels = true;
			scr.UseLayoutRounding = true;
			scr.CanContentScroll = true;
			scr.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			scr.VerticalContentAlignment = VerticalAlignment.Stretch;
			scr.VerticalAlignment = VerticalAlignment.Stretch;
			scr.HorizontalAlignment = HorizontalAlignment.Stretch;
			scr.Height = double.NaN;
			scr.Width = double.NaN;
			scr.Content = image;

			grid.Children.Add(block);
			grid.Children.Add(scr);
			Grid.SetRow(block, 0);
			Grid.SetRow(scr, 1);

			return grid;
		}

		private Grid GetLocalLayerWeightsBitmap(Layer layer, bool inverted = false)
		{
			double weightMin = layer.Weights.Min(weight => weight.Value);
			double weightMax = layer.Weights.Max(weight => weight.Value);
			double range = GetRangeFactor(weightMin, weightMax);

			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");

			string tabMin = weightMin < 0 ? " " : "  ";
			string tabMax = weightMax < 0 ? " " : "  ";

			if (inverted)
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (white)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (black)";
			else
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (black)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (white)";
			
			block.Text += "\n\n\n Local layers weight values can only be properly displayed in 3 dimensions";
			
			grid.Children.Add(block);
		   
			Grid.SetRow(block, 0);
		   
			return grid;
		}

		private Grid GetWeightlessPoolingLayerWeightsBitmap(Layer layer)
		{
			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");
			block.Text = "\n This is a weightless pooling layer\n";
		   
			grid.Children.Add(block);
			Grid.SetRow(block, 0);

			return grid;
		}

        private Grid GetWeightlessNormalizationLayerWeightsBitmap(Layer layer)
        {
            Grid grid = new Grid();
            grid.Width = double.NaN;
            grid.Height = double.NaN;
            grid.RowDefinitions.Add(new RowDefinition());

            TextBlock block = new TextBlock();
            block.FontFamily = new System.Windows.Media.FontFamily("Consolas");
            block.Text = "\n This is a weightless pooling layer\n";

            grid.Children.Add(block);
            Grid.SetRow(block, 0);

            return grid;
        }

		private Grid GetConvolutionalLayerWeightsBitmap(Layer layer, bool inverted = false)
		{
			double weightMin = layer.Weights.Min(weight => weight.Value);
			double weightMax = layer.Weights.Max(weight => weight.Value);
			double range = GetRangeFactor(weightMin, weightMax);

			int width = (layer.MapCount * layer.ReceptiveFieldHeight) + layer.MapCount + 1;
			int height = (layer.PreviousLayer.MapCount * layer.ReceptiveFieldWidth) + (3*layer.PreviousLayer.MapCount);
			int size = width * height;

			System.Windows.Controls.Image image = new System.Windows.Controls.Image();
			image.Stretch = Stretch.Uniform;
			image.StretchDirection = StretchDirection.Both;
			image.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
			image.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
			image.SnapsToDevicePixels = true;
			image.UseLayoutRounding = true;
			RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
			image.Width = width * Properties.Settings.Default.BlockSize;
			image.Height = height * Properties.Settings.Default.BlockSize;

			byte[] img = new byte[size];
			for (int i = 0; i < size; i++)
				img[i] = 255;

			if (layer.PreviousLayer.MapCount > 1)
			{
				int mapping = 0;
				
				if (inverted)
				{
					mapping = 0;
					for (int curMap = 0; curMap < layer.MapCount; curMap++)
						for(int prevMap=0; prevMap < layer.PreviousLayer.MapCount; prevMap++)
							if (layer.IsFullyMapped || layer.Mappings.IsMapped(curMap, prevMap, layer.MapCount))
							{
								// bias
								int biasIndex = curMap;
								int bxx = 1 + (curMap * layer.ReceptiveFieldWidth) + curMap;
								int byy = 1 + layer.ReceptiveFieldHeight + (prevMap * layer.ReceptiveFieldHeight) + (prevMap * 3);
								img[bxx + (byy * width)] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[biasIndex].Value));

								int mapIndex = layer.MapCount + (mapping * (layer.ReceptiveFieldWidth * layer.ReceptiveFieldHeight));

								for (int y = 0; y < layer.ReceptiveFieldWidth; y++)
									for (int x = 0; x < layer.ReceptiveFieldHeight; x++)
									{
										int index = x + (y * layer.ReceptiveFieldWidth) + mapIndex;
										int xx = 1 + x + (curMap * layer.ReceptiveFieldWidth) + curMap;
										int yy = y + (prevMap * layer.ReceptiveFieldHeight) + (prevMap * 3);
										img[xx + (yy * width)] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[index].Value));
									}

								mapping++;
							}
				}
				else
				{
					mapping = 0;
					for(int curMap=0; curMap < layer.MapCount; curMap++)
						for (int prevMap = 0; prevMap < layer.PreviousLayer.MapCount; prevMap++)
							if (layer.IsFullyMapped || layer.Mappings.IsMapped(curMap, prevMap, layer.MapCount))
							{
								int mapIndex = layer.MapCount + (mapping * (layer.ReceptiveFieldWidth * layer.ReceptiveFieldHeight));

								// bias
								int biasIndex = curMap;
								int bxx = 1 + (curMap * layer.ReceptiveFieldWidth) + curMap;
								int byy = 1 + layer.ReceptiveFieldHeight + (prevMap * layer.ReceptiveFieldHeight) + (prevMap * 3);
								img[bxx + (byy * width)] = GetColorFromRange(range, weightMin, layer.Weights[biasIndex].Value);
								
								for (int y = 0; y < layer.ReceptiveFieldWidth; y++)
									for (int x = 0; x < layer.ReceptiveFieldHeight; x++)
									{
										int index = x + (y * layer.ReceptiveFieldWidth) + mapIndex;
										int xx = 1 + x + (curMap * layer.ReceptiveFieldWidth) + curMap;
										int yy = y + (prevMap * layer.ReceptiveFieldHeight) + (prevMap * 3);
										img[xx + (yy * width)] = GetColorFromRange(range, weightMin, layer.Weights[index].Value);
									}
								
								mapping++;
							}
				}
			}
			else
			{
				int mapIndex = 0;
				if (inverted)
				{
					for (int map = 0; map < layer.MapCount; map++)
					{
						// bias
						int biasIndex = map;
						int bxx = 1 + (map * layer.ReceptiveFieldWidth) + map;
						int byy = 2 + layer.ReceptiveFieldHeight;
						img[bxx + (byy * width)] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[biasIndex].Value));

						mapIndex = layer.MapCount + (map * (layer.ReceptiveFieldWidth * layer.ReceptiveFieldHeight));
						int index = 0;
						for (int y = 0; y < layer.ReceptiveFieldWidth; y++)
							for (int x = 0; x < layer.ReceptiveFieldHeight; x++)
							{
								index = x + (y * layer.ReceptiveFieldWidth) + mapIndex;
								int xx = 1 + x + (map * layer.ReceptiveFieldWidth) + map;
								int yy = 1 + y;
								img[xx + (yy * width)] = (byte)(255 - GetColorFromRange(range, weightMin, layer.Weights[index].Value));
							}
					 }
				}
				else
				{
					for (int map = 0; map < layer.MapCount; map++)
					{
						// bias
						int biasIndex = map;
						int bxx = 1 + (map * layer.ReceptiveFieldWidth) + map;
						int byy = 2 + layer.ReceptiveFieldHeight;
						img[bxx + (byy * width)] = GetColorFromRange(range, weightMin, layer.Weights[biasIndex].Value);

						mapIndex = layer.MapCount + (map * (layer.ReceptiveFieldWidth * layer.ReceptiveFieldHeight));
						int index = 0;
						for (int y = 0; y < layer.ReceptiveFieldWidth; y++)
							for (int x = 0; x < layer.ReceptiveFieldHeight; x++)
							{
								index = x + (y * layer.ReceptiveFieldWidth) + mapIndex;
								int xx = 1 + x + (map * layer.ReceptiveFieldWidth) + map;
								int yy = 1 + y;
								img[xx + (yy * width)] = GetColorFromRange(range, weightMin, layer.Weights[index].Value);
							}
					}
				}
			}

			BitmapSource output = BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, img, width);
			if (output.CanFreeze)
				output.Freeze();
			image.Source = output;

			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			RowDefinition row = new RowDefinition();
			row.Height = new GridLength(50);
			grid.RowDefinitions.Add(row);
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");

			string tabMin = weightMin < 0 ? " " : "  ";
			string tabMax = weightMax < 0 ? " " : "  ";

			if (inverted)
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (black)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (white)";
			else
				block.Text = "\n Minimum:" + tabMin + weightMin.ToString("N17", CultureInfo.CurrentUICulture) + " (white)\n" + " Maximum:" + tabMax + weightMax.ToString("N17", CultureInfo.CurrentUICulture) + " (black)";

			ScrollViewer scr = new ScrollViewer();
			scr.SnapsToDevicePixels = true;
			scr.UseLayoutRounding = true;
			scr.CanContentScroll = true;
			scr.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			scr.VerticalContentAlignment = VerticalAlignment.Stretch;
			scr.VerticalAlignment = VerticalAlignment.Stretch;
			scr.HorizontalAlignment = HorizontalAlignment.Stretch;
			scr.Height = double.NaN;
			scr.Width = double.NaN;
			scr.Content = image;
						
			grid.Children.Add(block);
			grid.Children.Add(scr);
			Grid.SetRow(block, 0);
			Grid.SetRow(scr, 1);

			return grid;
		}

		private Grid GetMappedLayerOutputsBitmap(Layer layer, bool inverted = false)
		{
			double neuronMin = layer.Neurons.Min(neuron => neuron.Output);
			double neuronMax = layer.Neurons.Max(neuron => neuron.Output);
			double range = GetRangeFactor(neuronMin, neuronMax);

			int width = (layer.MapCount * layer.MapWidth) + layer.MapCount + 1;
			int height = layer.MapHeight + 2;
			int size = width * height;

			System.Windows.Controls.Image image = new System.Windows.Controls.Image();
			image.Stretch = Stretch.Uniform;
			image.StretchDirection = StretchDirection.Both;
			image.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
			image.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
			RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
			image.Width = width * Properties.Settings.Default.BlockSize;
			image.Height = height * Properties.Settings.Default.BlockSize;

			byte[] img = new byte[size];
			for (int i = 0; i < size; i++)
				img[i] = 255;

			if (inverted)
			{
				for (int map = 0; map < layer.MapCount; map++)
				{
					int mapIndex = map * layer.MapWidth * layer.MapHeight;
					for (int y = 0; y < layer.MapHeight; y++)
						for (int x = 0; x < layer.MapWidth; x++)
						{
							int index = x + (y * layer.MapWidth) + mapIndex;
							int xx = 1 + x + (map * layer.MapWidth) + map;
							int yy = y + 1;
							img[xx + (yy * width)] = (byte)(255 - GetColorFromRange(range, neuronMin, layer.Neurons[index].Output));
						}
				}
			}
			else
			{
				for (int map = 0; map < layer.MapCount; map++)
				{
					int mapIndex = map * layer.MapWidth * layer.MapHeight;
					for (int y = 0; y < layer.MapHeight; y++)
						for (int x = 0; x < layer.MapWidth; x++)
						{
							int index = x + (y * layer.MapWidth) + mapIndex;
							int xx = 1 + x + (map * layer.MapWidth) + map;
							int yy = y + 1;
							img[xx + (yy * width)] = GetColorFromRange(range, neuronMin, layer.Neurons[index].Output);
						}
				}
			}

			BitmapSource output = BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, img, width);
			if (output.CanFreeze)
				output.Freeze();
			image.Source = output;

			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			RowDefinition row = new RowDefinition();
			row.Height = new GridLength(50);
			grid.RowDefinitions.Add(row);
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");
			string tabMin = neuronMin < 0 ? " " : "  ";
			string tabMax = neuronMax < 0 ? " " : "  ";
			if (inverted)
				block.Text = "\n Minimum:" + tabMin + neuronMin.ToString("N17", CultureInfo.CurrentUICulture) + " (black)\n" + " Maximum:" + tabMax + neuronMax.ToString("N17", CultureInfo.CurrentUICulture) + " (white)";
			else
				block.Text = "\n Minimum:" + tabMin + neuronMin.ToString("N17", CultureInfo.CurrentUICulture) + " (white)\n" + " Maximum:" + tabMax + neuronMax.ToString("N17", CultureInfo.CurrentUICulture) + " (black)";

			ScrollViewer scr = new ScrollViewer();
			scr.SnapsToDevicePixels = true;
			scr.UseLayoutRounding = true;
			scr.CanContentScroll = true;
			scr.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			scr.VerticalContentAlignment = VerticalAlignment.Stretch;
			scr.VerticalAlignment = VerticalAlignment.Stretch;
			scr.HorizontalAlignment = HorizontalAlignment.Stretch;
			scr.Height = double.NaN;
			scr.Width = double.NaN;
			scr.Content = image;

			grid.Children.Add(block);
			grid.Children.Add(scr);
			Grid.SetRow(block, 0);
			Grid.SetRow(scr, 1);

			return grid;
		}

		private Grid GetLayerOutputsBitmap(Layer layer, bool inverted = false)
		{
			double neuronMin = layer.Neurons.Min(neuron => neuron.Output);
			double neuronMax = layer.Neurons.Max(neuron => neuron.Output);
			double range = GetRangeFactor(neuronMin, neuronMax);

			int width = (2 * layer.NeuronCount) + 1;
			int height = 3;
			int size = width * height;

			System.Windows.Controls.Image image = new System.Windows.Controls.Image();
			image.Stretch = Stretch.Uniform;
			image.StretchDirection = StretchDirection.Both;
			image.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
			image.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
			RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);
			image.Width = width * Properties.Settings.Default.BlockSize;
			image.Height = height * Properties.Settings.Default.BlockSize;

			byte[] img = new byte[size];
			for (int i = 0; i < size; i++)
				img[i] = 255;

			if (inverted)
				for (int i = 0; i < layer.NeuronCount; i++)
					img[1 + (i * 2) + width] = GetColorFromRange(range, neuronMin, layer.Neurons[i].Output);
			else
				for (int i = 0; i < layer.NeuronCount; i++)
					img[1 + (i * 2) + width] = (byte)(255 - GetColorFromRange(range, neuronMin, layer.Neurons[i].Output));
			
			BitmapSource output = BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, img, width);
			if (output.CanFreeze)
				output.Freeze();
			image.Source = output;

			Grid grid = new Grid();
			grid.Width = double.NaN;
			grid.Height = double.NaN;
			RowDefinition row = new RowDefinition();
			row.Height = new GridLength(50);
			grid.RowDefinitions.Add(row);
			grid.RowDefinitions.Add(new RowDefinition());

			TextBlock block = new TextBlock();
			block.FontFamily = new System.Windows.Media.FontFamily("Consolas");
			string tabMin = neuronMin < 0 ? " " : "  ";
			string tabMax = neuronMax < 0 ? " " : "  ";
			if (inverted)
				block.Text = "\n Minimum:" + tabMin + neuronMin.ToString("N17", CultureInfo.CurrentUICulture) + " (black)\n" + " Maximum:" + tabMax + neuronMax.ToString("N17", CultureInfo.CurrentUICulture) + " (white)";
			else
				block.Text = "\n Minimum:" + tabMin + neuronMin.ToString("N17", CultureInfo.CurrentUICulture) + " (white)\n" + " Maximum:" + tabMax + neuronMax.ToString("N17", CultureInfo.CurrentUICulture) + " (black)";

			ScrollViewer scr = new ScrollViewer();
			scr.SnapsToDevicePixels = true;
			scr.UseLayoutRounding = true;
			scr.CanContentScroll = true;
			scr.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			scr.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			scr.VerticalContentAlignment = VerticalAlignment.Stretch;
			scr.VerticalAlignment = VerticalAlignment.Stretch;
			scr.HorizontalAlignment = HorizontalAlignment.Stretch;
			scr.Height = double.NaN;
			scr.Width = double.NaN;
			scr.Content = image;

			grid.Children.Add(block);
			grid.Children.Add(scr);
			Grid.SetRow(block, 0);
			Grid.SetRow(scr, 1);

			return grid;
		}

		private void BlockSizeIntegerUpDown_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
		{
			Properties.Settings.Default.BlockSize = (int)e.NewValue;
			
			if (pageViewModel != null)
			{
				if (calculatePVM != null)
					ShowCalculateOutput();

				needRefreshWeightsView = true;  
				if (designPVM != null)
					RefreshWeightsView();
			}

			e.Handled = true;
		}
	}
}
