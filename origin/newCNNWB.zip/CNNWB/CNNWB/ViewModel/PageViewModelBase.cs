﻿using CNNWB.Model;
using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace CNNWB.ViewModel
{
    /// <summary>
    /// Abstract base class for all pages shown in the application MainWindow.
    /// </summary>
    public abstract class PageViewModelBase: INotifyPropertyChanged
    {
        #region Fields

        private DataProvider dataProvider;
        private NeuralNetwork neuralNetwork;
        private ObservableCollection<Control> commandToolBar;
        private Visibility commandToolBarVisibility;
        private bool isValid = true;
        
        #endregion // Fields

        #region Events

        /// <summary>
        /// Event definitions.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        public event EventHandler NeuralNetworkChanged;
        public event EventHandler DataProviderChanged;
        #endregion // Events

        #region Constructor

        protected PageViewModelBase(DataProvider dataprovider, NeuralNetwork network)
        {
            DataProvider = dataprovider;
            NeuralNetwork = network;
            commandToolBarVisibility = Visibility.Hidden;
            commandToolBar = new ObservableCollection<Control>();
            commandToolBar.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(commandToolBarCollectionChanged);
        }

        #endregion // Constructor

        #region Event Handlers
        void OnNeuralNetworkChanged()
        {
            EventHandler handler = NeuralNetworkChanged;
            if (handler != null)
                handler(this, EventArgs.Empty);
        }

        void OnDataProviderChanged()
        {
            EventHandler handler = DataProviderChanged;
            if (handler != null)
                handler(this, EventArgs.Empty);
        }
        #endregion // Event Handlers 

        #region Properties

        /// <summary>
        /// Returns and sets the dataprovider used.
        /// </summary>
        public DataProvider DataProvider
        {
            get { return dataProvider; }
            set
            {
                if (value == dataProvider)
                    return;
                
                dataProvider = value;
                this.OnPropertyChanged("DataProvider");
            }
        }

        /// <summary>
        /// Returns and sets the neural network used
        /// </summary>
        public NeuralNetwork NeuralNetwork
        {
            get { return neuralNetwork; }
            set
            {
                if (value == neuralNetwork)
                    return;

                neuralNetwork = value;
                this.OnPropertyChanged("NeuralNetwork");
                this.OnNeuralNetworkChanged();
            }
        }

        public Visibility CommandToolBarVisibility
        {
            get { return commandToolBarVisibility; }
 
            set
            {
                if (commandToolBarVisibility == value)
                    return;

                commandToolBarVisibility = value;
                this.OnPropertyChanged("CommandToolBarVisibility");
            }
        }

        /// <summary>
        /// Returns and sets the command toolbar used
        /// </summary>
        public ObservableCollection<Control> CommandToolBar
        {
            get
            {
                return commandToolBar; 
            }
            set
            {
                if (value == commandToolBar)
                    return;

                commandToolBar = value;
                this.OnPropertyChanged("CommandToolBar");
            }
        }

        public abstract string DisplayName { get; }

        public abstract void Reset();
        
        /// <summary>
        /// Returns false if the user has not completed this page properly
        /// and the application should not allow the user to progress to an 
        /// other page in the workflow.
        /// </summary>
        public bool IsValid
        {
            get
            {
                return isValid;
            }
            set
            {
                if (value == isValid)
                    return;

                isValid = value;
                this.OnPropertyChanged("IsValid");
            }
        }
        #endregion // Properties

        private void commandToolBarCollectionChanged(Object sender, NotifyCollectionChangedEventArgs e)
        {
            if (CommandToolBar.Count > 0)
                CommandToolBarVisibility = Visibility.Visible;
            else
                CommandToolBarVisibility = Visibility.Collapsed;
        }

        #region INotifyPropertyChanged Members

        protected virtual void OnPropertyChanged(string propertyName)
        {
            this.VerifyPropertyName(propertyName);

            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Debugging Aides

        /// <summary>
        /// Warns the developer if this object does not have
        /// a public property with the specified name. This 
        /// method does not exist in a Release build.
        /// </summary>
        [Conditional("DEBUG")]
        [DebuggerStepThrough]
        public void VerifyPropertyName(string propertyName)
        {
            // If you raise PropertyChanged and do not specify a property name,
            // all properties on the object are considered to be changed by the binding system.
            if (String.IsNullOrEmpty(propertyName))
                return;

            // Verify that the property name matches a real,  
            // public, instance property on this object.
            if (TypeDescriptor.GetProperties(this)[propertyName] == null)
            {
                string msg = "Invalid property name: " + propertyName;

                if (this.ThrowOnInvalidPropertyName)
                    throw new ArgumentException(msg);
                else
                    Debug.Fail(msg);
            }
        }

        /// <summary>
        /// Returns whether an exception is thrown, or if a Debug.Fail() is used
        /// when an invalid property name is passed to the VerifyPropertyName method.
        /// The default value is false, but subclasses used by unit tests might 
        /// override this property's getter to return true.
        /// </summary>
        protected virtual bool ThrowOnInvalidPropertyName { get; private set; }

        #endregion // Debugging Aides

        #endregion // INotifyPropertyChanged Members
    }
}
