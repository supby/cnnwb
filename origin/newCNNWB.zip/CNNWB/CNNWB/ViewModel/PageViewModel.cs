﻿using CNNWB.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace CNNWB.ViewModel
{
    public enum ContextTypes
    {
        Training = 0,
        Design = 1,
        Testing = 2,
        Calculate = 3
    }

    /// <summary>
    /// The main ViewModel class for application.
    /// This class contains the various pages shown
    /// in the workflow and provides navigation
    /// between the pages.
    /// </summary>
    public class PageViewModel : INotifyPropertyChanged
    {
        private ContextTypes currentContext;
        private DataProvider dataProvider;
        private NeuralNetwork neuralNetwork;
        private ObservableCollection<Control> commandToolBar;
        private Visibility commandToolBarVisibility;
        private PageViewModelBase currentPage;
        private ReadOnlyCollection<PageViewModelBase> pages;
        private int maxDegreeOfParallelism = Environment.ProcessorCount;

        public PageViewModel(DataProvider dataProvider, NeuralNetwork network)
        {
            DataProvider = dataProvider;
            NeuralNetwork = network;
            MaxDegreeOfParallelism = Environment.ProcessorCount;
            CurrentPage = Pages[0];
            CurrentPage.CommandToolBar = Pages[0].CommandToolBar;
        }

        /// <summary>
        /// Event definitions.
        /// </summary>
        public event EventHandler PageChange;

        /// <summary>
        /// Returns and sets the current page context used.
        /// </summary>
        public ContextTypes CurrentContext
        {
            get { return currentContext; }
            set 
            {
                if (value == currentContext)
                    return;

                currentContext = value;
                OnPropertyChanged("CurrentContext");
            }
        }

        /// <summary>
        /// Returns and sets the dataprovider used.
        /// </summary>
        public DataProvider DataProvider
        {
            get { return dataProvider; }
            set
            {
                if (value == dataProvider)
                    return;

                dataProvider = value;
                foreach (PageViewModelBase model in Pages)
                {
                    model.DataProvider = dataProvider;
                }
                OnPropertyChanged("DataProvider");
            }
        }

        /// <summary>
        /// Returns and sets the neural network used
        /// </summary>
        public NeuralNetwork NeuralNetwork
        {
            get { return neuralNetwork; }
            set
            {
                if (value == neuralNetwork)
                    return;

                neuralNetwork = value;
                foreach (PageViewModelBase model in Pages)
                {
                    model.NeuralNetwork = neuralNetwork;
                }
                OnPropertyChanged("NeuralNetwork");
            }
        }

        /// <summary>
        /// Returns and sets the command toolbar used
        /// </summary>
        public ObservableCollection<Control> CommandToolBar
        {
            get
            {
                if (commandToolBar == null)
                    commandToolBar = new ObservableCollection<Control>();

                return commandToolBar;
            }
            set
            {
                if (value == commandToolBar)
                    return;

                commandToolBar = value;
                OnPropertyChanged("CommandToolBar");
            }
        }

        public Visibility CommandToolBarVisibility
        {
            get 
            {
                return commandToolBarVisibility;
            }
            set
            {
                if (value == commandToolBarVisibility)
                    return;

                commandToolBarVisibility = value;
                OnPropertyChanged("CommandToolBarVisibility");
            }
        }

        /// <summary>
        /// Returns the page ViewModel that the user is currently viewing.
        /// </summary>
        public PageViewModelBase CurrentPage
        {
            get { return currentPage; }
            set
            {
                if (value == currentPage)
                    return;

                if (value == null)
                    return;
                
                currentPage = value;
                CommandToolBar = currentPage.CommandToolBar;
                CommandToolBarVisibility = currentPage.CommandToolBarVisibility;
                OnPropertyChanged("CurrentPage");
                OnPageChange();
            }
        }

        /// <summary>
        /// Returns a read-only collection of all page ViewModels.
        /// </summary>
        public ReadOnlyCollection<PageViewModelBase> Pages
        {
            get
            {
                if (pages == null)
                    this.CreatePages();

                return pages;
            }
        }

        public void Reset()
        {
            foreach (PageViewModelBase page in Pages)
            {
                page.Reset();
            }
        }

        public int MaximalDegreeOfParallelism
        {
            get
            {
                return Environment.ProcessorCount;
            }
        }

        /// <summary>
        /// Value represents te number of cores used in parallel processing.
        /// </summary>
        public int MaxDegreeOfParallelism
        {
            get
            {
                return maxDegreeOfParallelism;
            }
            set
            {
                if (value == maxDegreeOfParallelism)
                    return;

                maxDegreeOfParallelism = value;

                if (DataProvider != null)
                    DataProvider.MaxDegreeOfParallelism = maxDegreeOfParallelism;
                if (NeuralNetwork != null)
                    NeuralNetwork.MaxDegreeOfParallelism = maxDegreeOfParallelism;
                
                this.OnPropertyChanged("MaxDegreeOfParallelism");
            }
        }
        
        void CreatePages()
        {
            var TrainingPageVM = new TrainingPageViewModel(DataProvider, NeuralNetwork);
            var DesignPageVM = new DesignPageViewModel(DataProvider, NeuralNetwork);
            var TestingPageVM = new TestingPageViewModel(DataProvider, NeuralNetwork);
            var CalculatePageVM = new CalculatePageViewModel(DataProvider, NeuralNetwork);
            List<PageViewModelBase> listPages = new List<PageViewModelBase>();
            listPages.Add(TrainingPageVM);
            listPages[0].CommandToolBar = TrainingPageVM.CommandToolBar;
            listPages.Add(DesignPageVM);
            listPages[1].CommandToolBar = DesignPageVM.CommandToolBar;
            listPages.Add(TestingPageVM);
            listPages[2].CommandToolBar = TestingPageVM.CommandToolBar;
            listPages.Add(CalculatePageVM);
            listPages[3].CommandToolBar = CalculatePageVM.CommandToolBar;
           
            pages = new ReadOnlyCollection<PageViewModelBase>(listPages);
        }

        int CurrentPageIndex
        {
            get
            {
                if (CurrentPage == null)
                {
                    Debug.Fail("Why is the current page null?");
                    return -1;
                }

                return Pages.IndexOf(CurrentPage);
            }
        }

        void OnPageChange()
        {
            CurrentContext = (ContextTypes)CurrentPageIndex;

            EventHandler handler = this.PageChange;
            if (handler != null)
                handler(this, EventArgs.Empty);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
