﻿using CNNWB.Common;
using CNNWB.Model;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CNNWB.ViewModel
{
    class DesignPageViewModel : PageViewModelBase
    {
        private ObservableCollection<TabItem> tabItems = null;
        private string description = String.Empty;
        private int selectedLayerIndex = -1;
        private bool inverted = Properties.Settings.Default.InvertedDesignView;
        private Brush backgroundColor;
        private double minimum;
        private double maximum;
        
        public event EventHandler Invert;

        public DesignPageViewModel() : base(null,  null)
        {
            AddCommandButtons();

            base.OnPropertyChanged("NeuralNetwork");
            NeuralNetworkChanged += this.OnNeuralNetworkChanged;
        }

        public DesignPageViewModel(DataProvider dataProvider, NeuralNetwork neuralNetwork) : base(dataProvider, neuralNetwork)
        {
            AddCommandButtons();
                       
            NeuralNetworkChanged += this.OnNeuralNetworkChanged;
        }

        private void AddCommandButtons()
        {
            Button invertButton = new Button();
            invertButton.Name = "ButtonInvert";
            invertButton.ToolTip = "Invert Min/Max";
            invertButton.Content = new BitmapToImage(CNNWB.Properties.Resources.ForegroundColor_325);
            invertButton.ClickMode = ClickMode.Press;
            invertButton.Click += new RoutedEventHandler(InvertButtonClick);
            CommandToolBar.Add(invertButton);
        }

        public string Description
        {
            get { return description; }
            set
            {
                if (description == value)
                    return;

                description = value;
                OnPropertyChanged("Description");
            }
        }

        public ObservableCollection<TabItem> TabItems
        {
            get { return tabItems; }
            set
            {
                if (value == tabItems)
                    return;

                tabItems = value;
                OnPropertyChanged("TabItems");
            }
        }

        public System.Windows.Media.Brush BackgroundColor
        {
            get { return backgroundColor; }
            set
            {
                if (value == backgroundColor)
                    return;
                backgroundColor = value;
                OnPropertyChanged("BackgroundColor");
            }
        }

        public double Minimum
        {
            get { return minimum; }
            set
            {
                if (value == minimum)
                    return;

                minimum = value;
                OnPropertyChanged("Minimum");
            }
        }

        public double Maximum
        {
            get { return maximum; }
            set
            {
                if (value == maximum)
                    return;

                maximum = value;
                OnPropertyChanged("Maximum");
            }
        }

        public bool Inverted
        {
            get { return inverted; }
            set
            {
                if (value == inverted)
                    return;

                inverted = value;
                Properties.Settings.Default.InvertedDesignView = inverted;
                OnPropertyChanged("Inverted");
            }
        }

        public int SelectedLayerIndex
        {
            get { return selectedLayerIndex; }
            set
            {
                if (value == selectedLayerIndex)
                    return;

                selectedLayerIndex = value;
                OnPropertyChanged("SelectedLayerIndex");
            }
        }

        public override string DisplayName
        {
            get { return "Design"; }
        }

        public override void Reset()
        {
            //Description = String.Empty;
        }

        private void OnNeuralNetworkChanged(object sender, EventArgs e)
        {
            Description = NeuralNetwork.Description;
        }

        void InvertButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = this.Invert;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }
    }
}
