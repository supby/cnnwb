﻿using CNNWB.Common;
using CNNWB.Model;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CNNWB.ViewModel
{
    class CalculatePageViewModel : PageViewModelBase
    {
        private int sampleIndex = 0;
        private ObservableCollection<TabItem> tabItems = null;
        private ImageSource sampleImage;
        private string result = String.Empty;
        private bool useDistortions = false;
        private bool useTrainingSet = false;
        private bool inverted = Properties.Settings.Default.InvertedCalculateView;
        private double severityFactor = Properties.Settings.Default.SeverityFactor;
        private double maxScaling = Properties.Settings.Default.MaxScaling;
        private double maxRotation = Properties.Settings.Default.MaxRotation;
        private double elasticSigma = Properties.Settings.Default.ElasticSigma;
        private double elasticScaling = Properties.Settings.Default.ElasticScaling;
        private int selectedTabIndex = -1;
        private double minimum;
        private double maximum;
        private string label = String.Empty;
        private bool autoCalculate = Properties.Settings.Default.AutoCalculate;
               
        #region Events
        /// <summary>
        /// Event definitions.
        /// </summary>
        public event EventHandler Calculate;
        public event EventHandler Refresh;
        public event EventHandler Invert;
        public event EventHandler SampleIndexChanged;
        public event EventHandler UseTrainingSetChanged;
        public event EventHandler UseDistortionsChanged;
        #endregion // Events

        public CalculatePageViewModel() : base(null,  null)
        {
            AddCommandButtons();
        }

        public CalculatePageViewModel(DataProvider dataProvider, NeuralNetwork neuralNetwork) : base(dataProvider, neuralNetwork)
        {
            AddCommandButtons();
        }

        private void AddCommandButtons()
        {
            Button calculateButton = new Button();
            calculateButton.Name = "ButtonCalculate";
            calculateButton.ToolTip = "Calculate Network";
            calculateButton.Content = new BitmapToImage(CNNWB.Properties.Resources.CalculatorHS);
            calculateButton.ClickMode = ClickMode.Press;
            calculateButton.Click += new RoutedEventHandler(CalculateButtonClick);
            CommandToolBar.Add(calculateButton);
            //Button refreshButton = new Button();
            //refreshButton.Name = "ButtonRefresh";
            //refreshButton.ToolTip = "Refresh Distortion";
            //refreshButton.Content = new BitmapToImage(CNNWB.Properties.Resources.Refresh);
            //refreshButton.ClickMode = ClickMode.Press;
            //refreshButton.Click += new RoutedEventHandler(RefreshButtonClick);
            //CommandToolBar.Add(refreshButton);
            Button invertButton = new Button();
            invertButton.Name = "ButtonInvert";
            invertButton.ToolTip = "Invert Min/Max";
            invertButton.Content = new BitmapToImage(CNNWB.Properties.Resources.ForegroundColor_325);
            invertButton.ClickMode = ClickMode.Press;
            invertButton.Click += new RoutedEventHandler(InvertButtonClick);
            CommandToolBar.Add(invertButton);
        }

        public override void Reset()
        {
            SampleIndex = 1;
            SampleIndex = 0;
            if (TabItems != null)
                TabItems = null;
            Result = String.Empty;
            UseDistortions = false;
            UseTrainingSet = false;
            SeverityFactor = Properties.Settings.Default.SeverityFactor;
            MaxScaling = Properties.Settings.Default.MaxScaling;
            MaxRotation = Properties.Settings.Default.MaxRotation;
            ElasticSigma = Properties.Settings.Default.ElasticSigma;
            ElasticScaling = Properties.Settings.Default.ElasticScaling;
            Inverted = Properties.Settings.Default.InvertedCalculateView;
            AutoCalculate = Properties.Settings.Default.AutoCalculate;
        }

        public bool AutoCalculate
        {
            get { return autoCalculate; }
            set 
            {
                if (value == autoCalculate)
                    return;

                autoCalculate = value;
                Properties.Settings.Default.AutoCalculate = value;
                Properties.Settings.Default.Save();
                OnPropertyChanged("AutoCalculate");
            }
        }

        public string Label
        {
            get { return label; }
            set
            {
                if (value == label)
                    return;

                label = value;
                OnPropertyChanged("Label");
            }
        }

        public double Minimum
        {
            get { return minimum; }
            set
            {
                if (value == minimum)
                    return;

                minimum = value;
                OnPropertyChanged("Minimum");
            }
        }

        public double Maximum
        {
            get { return maximum; }
            set
            {
                if (value == maximum)
                    return;

                maximum = value;
                OnPropertyChanged("Maximum");
            }
        }

        public string Result
        {
            get { return result; }
            set
            {
                if (value == result)
                    return;

                result = value;
                OnPropertyChanged("Result");
            }
        }

        public ObservableCollection<TabItem> TabItems
        {
            get { return tabItems; }
            set
            {
                if (value == tabItems)
                    return;

                tabItems = value;
                OnPropertyChanged("TabItems");               
            }
            
        }

        public int SampleIndex
        {
            get { return sampleIndex; }
            set
            {
                if (value == sampleIndex )
                    return;

                sampleIndex = value;
                OnPropertyChanged ("SampleIndex");
                OnSampleIndexChanged();
            }
        }

        public ImageSource SampleImage
        {
            get { return sampleImage; }
            set
            {
                if (value == sampleImage)
                    return;

                sampleImage = value;
                OnPropertyChanged("SampleImage");
            }
        }

        public bool UseDistortions
        {
            get { return useDistortions; }
            set
            {
                if (value == useDistortions)
                    return;

                useDistortions = value;
                OnPropertyChanged("UseDistortions");
                OnUseDistortionsChanged();
                RefreshButtonClick(this, null);
            }
        }

        public bool UseTrainingSet
        {
            get { return useTrainingSet; }
            set
            {
                if (value == useTrainingSet)
                    return;

                useTrainingSet = value;
                OnPropertyChanged("UseTrainingSet");
                OnUseTrainingSetChanged();
                RefreshButtonClick(this, null);
            }
        }

        public bool Inverted
        {
            get { return inverted; }
            set
            {
                if (value == inverted)
                    return;

                inverted = value;
                Properties.Settings.Default.InvertedCalculateView = inverted;
                OnPropertyChanged("Inverted");
            }
        }

        public double SeverityFactor
        {
            get { return severityFactor; }
            set
            {
                if (value == severityFactor)
                    return;

                severityFactor = value;
                OnPropertyChanged("SeverityFactor");
                RefreshButtonClick(this, null);
            }

        }

        public double MaxScaling
        {
            get { return maxScaling; }
            set
            {
                if (value == maxScaling)
                    return;

                maxScaling = value;
                OnPropertyChanged("MaxScaling");
                RefreshButtonClick(this, null);
            }
        }

        public double MaxRotation
        {
            get { return maxRotation; }
            set
            {
                if (value == maxRotation)
                    return;

                maxRotation = value;
                OnPropertyChanged("MaxRotation");
                RefreshButtonClick(this, null);
            }
        }

        public double ElasticSigma
        {
            get { return elasticSigma; }
            set
            {
                if (value == elasticSigma)
                    return;

                elasticSigma = value;
                OnPropertyChanged("ElasticSigma");
                RefreshButtonClick(this, null);
            }
        }

        public double ElasticScaling
        {
            get { return elasticScaling; }
            set
            {
                if (value == elasticScaling)
                    return;

                elasticScaling = value;
                OnPropertyChanged("ElasticScaling");
                RefreshButtonClick(this, null);
            }
        }

        public override string DisplayName
        {
            get { return "Calculate"; }
        }

        public int SelectedTabIndex
        {
            get { return selectedTabIndex; }
            set
            {
                if (value == selectedTabIndex)
                    return;

                selectedTabIndex = value;
                OnPropertyChanged("SelectedTabIndex");
            }
        }

        void CalculateButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = this.Calculate;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        public void RefreshButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = this.Refresh;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void InvertButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = this.Invert;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void OnSampleIndexChanged()
        {
            EventHandler handler = this.SampleIndexChanged;
            if (handler != null)
                handler.Invoke(this, EventArgs.Empty);
        }

        void OnUseTrainingSetChanged()
        {
            EventHandler handler = this.UseTrainingSetChanged;
            if (handler != null)
                handler.Invoke(this, EventArgs.Empty);
        }

        void OnUseDistortionsChanged()
        {
            EventHandler handler = this.UseDistortionsChanged;
            if (handler != null)
                handler.Invoke(this, EventArgs.Empty);
        }
    }
}
