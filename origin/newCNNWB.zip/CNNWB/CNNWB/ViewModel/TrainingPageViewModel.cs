﻿using CNNWB.Common;
using CNNWB.Model;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CNNWB.ViewModel
{
    public struct TrainingResult
    {
        public int Epoch { get; set; }
        public int DistortionPercentage { get; set; }
        public double TrainingRate { get; set; }
        public double AvgTrainLoss { get; set; }
        public int TrainErrors { get; set; }
        public double TrainErrorPercentage { get; set; }
        public double AvgTestLoss { get; set; }
        public int TestErrors { get; set; }
        public double TestErrorPercentage { get; set; }
        public double Accuracy { get; set; }
        public TimeSpan ElapsedTime { get; set; }

        public TrainingResult(int epoch, int distortionPercentage, double rate, double avgTrainLoss, int trainErrors, double trainErrorPercentage, double avgTestLoss, int testErrors, double testErrorPercentage, double accuracy, TimeSpan elapsedTime)
            : this()
        {
            Epoch = epoch;
            DistortionPercentage = distortionPercentage;
            TrainingRate = rate;
            AvgTrainLoss = avgTrainLoss;
            TrainErrors = trainErrors;
            TrainErrorPercentage = trainErrorPercentage;
            AvgTestLoss = avgTestLoss;
            TestErrors = testErrors;
            TestErrorPercentage = testErrorPercentage;
            Accuracy = accuracy;
            ElapsedTime = elapsedTime;
        }
    }

    public sealed class TrainingPageViewModel : PageViewModelBase
    {
        private String progressText;
        private ImageSource sampleImage;
        private String sampleLabel; 
        private ObservableCollection<TrainingResult> trainingResultCollection;
        private int selectedIndex = -1;
        private ComboBox trainingStrategy;
        private TrainingStrategy selectedTrainingStrategy;
        
        #region Events
        /// <summary>
        /// Event definitions.
        /// </summary>
        public event EventHandler Start;
        public event EventHandler Stop;
        public event EventHandler Pause;
        public event EventHandler Editor;
        public event EventHandler Forget;
        #endregion // Events

        public TrainingPageViewModel() : base(null,  null)
        {
            TrainingResultCollection = new ObservableCollection<TrainingResult>();
            AddCommandButtons();
        }

        public TrainingPageViewModel(DataProvider dataProvider, NeuralNetwork neuralNetwork) : base(dataProvider, neuralNetwork)
        {
            TrainingResultCollection = new ObservableCollection<TrainingResult>();
            AddCommandButtons();
            NeuralNetworkChanged += TrainingPageViewModel_NeuralNetworkChanged;
        }

        private void TrainingPageViewModel_NeuralNetworkChanged(object sender, EventArgs e)
        {
            if (NeuralNetwork != null)
                trainingStrategy.SelectedIndex = (int)NeuralNetwork.TrainingStrategy;
        }

        private void AddCommandButtons()
        {
            Button startButton = new Button();
            startButton.Name = "ButtonStart";
            startButton.ToolTip = "Start Training";
            startButton.Content = new BitmapToImage(CNNWB.Properties.Resources.PlayHS);
            startButton.ClickMode = ClickMode.Press;
            startButton.Click += new RoutedEventHandler(StartButtonClick);
            Button stopButton = new Button();
            stopButton.Name = "ButtonStop";
            stopButton.ToolTip = "Stop Training";
            stopButton.Content = new BitmapToImage(CNNWB.Properties.Resources.StopHS);
            stopButton.ClickMode = ClickMode.Press;
            stopButton.Click += new RoutedEventHandler(StopButtonClick);
            Button pauseButton = new Button();
            pauseButton.Name = "ButtonPause";
            pauseButton.ToolTip = "Pause Training";
            pauseButton.Content = new BitmapToImage(CNNWB.Properties.Resources.PauseHS);
            pauseButton.ClickMode = ClickMode.Press;
            pauseButton.Click += new RoutedEventHandler(PauseButtonClick);
            Button editorButton = new Button();
            editorButton.Name = "ButtonEditor";
            editorButton.ToolTip = "Training Scheme Editor";
            editorButton.Content = new BitmapToImage(CNNWB.Properties.Resources.Properties);
            editorButton.ClickMode = ClickMode.Press;
            editorButton.Click += new RoutedEventHandler(EditorButtonClick);
            Button forgetButton = new Button();
            forgetButton.Name = "ButtonForget";
            forgetButton.ToolTip = "Forget";
            forgetButton.Content = new BitmapToImage(CNNWB.Properties.Resources.base_star_16);
            forgetButton.ClickMode = ClickMode.Press;
            forgetButton.Click += new RoutedEventHandler(ForgetButtonClick);

            trainingStrategy = new ComboBox();
            trainingStrategy.Name = "ComboBoxTrainingStrategy";
            int index = 0;
            foreach (string strategy in Enum.GetNames(typeof(TrainingStrategy)))
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = strategy;
                item.Name = strategy;
                item.Tag = index++;
                trainingStrategy.Items.Add(item);
            }
            trainingStrategy.ToolTip = "Training Strategy";
            trainingStrategy.SelectionChanged += new SelectionChangedEventHandler(SelectionStrategyChanged);

            CommandToolBar.Add(startButton);
            CommandToolBar.Add(stopButton);
            CommandToolBar.Add(pauseButton);
            CommandToolBar.Add(editorButton);
            CommandToolBar.Add(forgetButton);
            CommandToolBar.Add(trainingStrategy);
        }

        public string ProgressText
        {
            get
            {
                return progressText;
            }
            set
            {
                if (value == progressText)
                    return;

                progressText = value;
                OnPropertyChanged("ProgressText");
            }
        }

        public ImageSource SampleImage
        {
            get { return sampleImage; }
            set
            {
                if (value == sampleImage)
                    return;

                sampleImage = value;
                OnPropertyChanged("SampleImage");
            }
        }

        public string SampleLabel
        {
            get
            {
                return sampleLabel;
            }
            set
            {
                if (value == sampleLabel)
                    return;

                sampleLabel = value;
                OnPropertyChanged("SampleLabel");
            }
        }

        public ObservableCollection<TrainingResult> TrainingResultCollection 
        {
            get { return trainingResultCollection; }
            private set
            {
                if (value == trainingResultCollection)
                    return;

                trainingResultCollection = value;
                OnPropertyChanged("TrainingResultCollection");
            }
        }

        public int SelectedIndex
        {
            get { return selectedIndex; }
            set
            {
                if (value == selectedIndex)
                    return;

                selectedIndex = value;
                OnPropertyChanged("SelectedIndex");
            }
        }

        public TrainingStrategy SelectedTrainingStrategy
        {
            get { return selectedTrainingStrategy; }
            set
            {
                if (value == selectedTrainingStrategy)
                    return;

                selectedTrainingStrategy = value;
                OnPropertyChanged("SelectedTrainingStrategy");
            }
        }
      
        public override string DisplayName
        {
            get { return "Training"; }
        }


        public override void Reset()
        {
            if (TrainingResultCollection != null)
                TrainingResultCollection.Clear();
            SelectedIndex = -1;
            ProgressText = String.Empty;
            SampleImage = null;
            SampleLabel = string.Empty;
        }

        void StartButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Start;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                e.Handled = true;
            }
        }

        void StopButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Stop;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void PauseButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Pause;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void EditorButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Editor;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void ForgetButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Forget;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void SelectionStrategyChanged(object sender, SelectionChangedEventArgs e)
        {
            SelectedTrainingStrategy = (TrainingStrategy)(sender as ComboBox).SelectedIndex;
            if (NeuralNetwork != null)
            {
                NeuralNetwork.TrainingStrategy = SelectedTrainingStrategy;
                NeuralNetwork.ChangeTrainingStrategy();
            }
            if (e != null)
                e.Handled = true;
        }
    }
}
