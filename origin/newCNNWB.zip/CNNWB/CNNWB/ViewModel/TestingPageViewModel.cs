﻿using CNNWB.Common;
using CNNWB.Model;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CNNWB.ViewModel
{
    public class TestingPageViewModel : PageViewModelBase
    {
        private String progressText;
        private ImageSource sampleImage;
        private String sampleLabel;
        private ConfusionMatrix confusionMatrix;
        private string confusionDocument;
        private bool useDistortions = false;
        private bool useTrainingSet = false;
        private int selectedTabIndex = -1;
        private double severityFactor = Properties.Settings.Default.SeverityFactor;
        private double maxScaling = Properties.Settings.Default.MaxScaling;
        private double maxRotation = Properties.Settings.Default.MaxRotation;
        private double elasticSigma = Properties.Settings.Default.ElasticSigma;
        private double elasticScaling = Properties.Settings.Default.ElasticScaling;

        #region Events
        /// <summary>
        /// Event definitions.
        /// </summary>
        public event EventHandler Start;
        public event EventHandler Stop;
        public event EventHandler Pause;
        #endregion // Events

        public TestingPageViewModel() : base(null, null)
        {
            UseTrainingSet = false;
            AddCommandButtons();
        }

        public TestingPageViewModel(DataProvider dataProvider, NeuralNetwork neuralNetwork) : base(dataProvider, neuralNetwork)
        {
            UseTrainingSet = false;
            confusionMatrix = new ConfusionMatrix("ConfusionMatrix", dataProvider);
            AddCommandButtons();
        }

        private void AddCommandButtons()
        {
            Button startButton = new Button();
            startButton.Name = "ButtonStart";
            startButton.ToolTip = "Start Testing";
            startButton.Content = new BitmapToImage(CNNWB.Properties.Resources.PlayHS);
            startButton.ClickMode = ClickMode.Press;
            startButton.Click += new RoutedEventHandler(StartButtonClick);
            Button stopButton = new Button();
            stopButton.Name = "ButtonStop";
            stopButton.ToolTip = "Stop Testing";
            stopButton.Content = new BitmapToImage(CNNWB.Properties.Resources.StopHS);
            stopButton.ClickMode = ClickMode.Press;
            stopButton.Click += new RoutedEventHandler(StopButtonClick);
            Button pauseButton = new Button();
            pauseButton.Name = "ButtonPause";
            pauseButton.ToolTip = "Pause Testing";
            pauseButton.Content = new BitmapToImage(CNNWB.Properties.Resources.PauseHS);
            pauseButton.ClickMode = ClickMode.Press;
            pauseButton.Click += new RoutedEventHandler(PauseButtonClick);
            CommandToolBar.Add(startButton);
            CommandToolBar.Add(stopButton);
            CommandToolBar.Add(pauseButton);
        }

        public ImageSource SampleImage
        {
            get { return sampleImage; }
            set
            {
                if (value == sampleImage)
                    return;

                sampleImage = value;
                OnPropertyChanged("SampleImage");
            }
        }

        public string SampleLabel
        {
            get
            {
                return sampleLabel;
            }
            set
            {
                if (value == sampleLabel)
                    return;

                sampleLabel = value;
                OnPropertyChanged("SampleLabel");
            }
        }

        public string ProgressText
        {
            get
            {
                return progressText;
            }
            set
            {
                if (value == progressText)
                    return;

                progressText = value;
                OnPropertyChanged("ProgressText");
            }
        }

        public ConfusionMatrix ConfusionMatrix
        {
            get { return confusionMatrix; }
            set
            {
                if (value == confusionMatrix)
                    return;

                confusionMatrix = value;
                OnPropertyChanged("ConfusionMatrix");
            }
        }

        public string ConfusionDocument
        {
            get { return confusionDocument; }
            set
            {
                if (value == confusionDocument)
                    return;

                confusionDocument = value;
                OnPropertyChanged("ConfusionDocument");
            }
        }

        public bool UseDistortions
        {
            get { return useDistortions; }
            set
            {
                if (value == useDistortions)
                    return;

                useDistortions = value;
                OnPropertyChanged("UseDistortions");
            }
        }

        public bool UseTrainingSet
        {
            get { return useTrainingSet; }
            set
            {
                if (value == useTrainingSet)
                    return;

                useTrainingSet = value;
                OnPropertyChanged("UseTrainingSet");
            }
        }

        public double SeverityFactor
        {
            get { return severityFactor; }
            set
            {
                if (value == severityFactor)
                    return;

                severityFactor = value;
                OnPropertyChanged("SeverityFactor");
            }

        }

        public double MaxScaling
        {
            get { return maxScaling; }
            set
            {
                if (value == maxScaling)
                    return;

                maxScaling = value;
                OnPropertyChanged("MaxScaling");
            }
        }

        public double MaxRotation
        {
            get { return maxRotation; }
            set
            {
                if (value == maxRotation)
                    return;

                maxRotation = value;
                OnPropertyChanged("MaxRotation");
            }
        }

        public double ElasticSigma
        {
            get { return elasticSigma; }
            set
            {
                if (value == elasticSigma)
                    return;

                elasticSigma = value;
                OnPropertyChanged("ElasticSigma");
            }
        }

        public double ElasticScaling
        {
            get { return elasticScaling; }
            set
            {
                if (value == elasticScaling)
                    return;

                elasticScaling = value;
                OnPropertyChanged("ElasticScaling");
            }
        }

        public override string DisplayName
        {
            get { return "Testing"; }
        }

        public int SelectedTabIndex
        {
            get { return selectedTabIndex; }
            set
            {
                if (value == selectedTabIndex)
                    return;

                selectedTabIndex = value;
                OnPropertyChanged("SelectedTabIndex");
            }
        }

        public override void Reset()
        {
            if (ConfusionMatrix != null)
                ConfusionMatrix.Clear();
            ConfusionMatrix = null;
           
            ProgressText = string.Empty;
            SampleImage = null;
            SampleLabel = string.Empty;
            ConfusionDocument = string.Empty;
            UseDistortions = false;
            UseTrainingSet = false;
            SelectedTabIndex = -1;
            SeverityFactor = Properties.Settings.Default.SeverityFactor;
            MaxScaling = Properties.Settings.Default.MaxScaling;
            MaxRotation = Properties.Settings.Default.MaxRotation;
            ElasticSigma = Properties.Settings.Default.ElasticSigma;
            ElasticScaling = Properties.Settings.Default.ElasticScaling;
        }

        void StartButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Start;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void StopButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Stop;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }

        void PauseButtonClick(object sender, RoutedEventArgs e)
        {
            EventHandler handler = Pause;
            if (handler != null)
            {
                handler.Invoke(this, EventArgs.Empty);
                if (e != null)
                    e.Handled = true;
            }
        }
    }
}
