﻿using CNNWB.Model;
using ICSharpCode.SharpZipLib.Tar;
using System;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using TaskDialogInterop;

namespace CNNWB.Dialogs
{
    /// <summary>
    /// Interaction logic for DownloadDatasets.xaml
    /// </summary>
    public partial class DownloadDatasets : Window
    {
        public DataProvider DataProvider { get; set; }
        public bool AllDownloaded { get; private set; }
        private delegate void ShowProgressDelegate(System.Object sender, DownloadProgressChangedEventArgs e);
        private delegate void DownloadFinishedDelegate(System.Object sender, DownloadDataCompletedEventArgs e);
        private ShowProgressDelegate showProgress;
        private DownloadFinishedDelegate downloadFinished;
        private Task[] tasks;
        private int numTasks = 0;
        private int tasksCompleted = 0;
        private int errors = 0;        

        public DownloadDatasets()
        {
            InitializeComponent();
            AllDownloaded = false;
            showProgress = ShowProgress;
            downloadFinished = DownloadFinished;
        }

        private void DownloadDatasetsWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (DataProvider.DataSetDownloadInfo != null)
            {
                Thickness margin = new Thickness(3);
                foreach (DatasetDownloadInformation dataset in DataProvider.DataSetDownloadInfo)
                {
                    if (!DataProvider.DataSetFilesAvailable(dataset.DataProviderSet))
                    {
                        GroupBox groupBox = new GroupBox();
                        groupBox.Header = dataset.Name;
                        groupBox.FontWeight = FontWeights.Bold;
                        groupBox.Width = double.NaN;
                        groupBox.Height = double.NaN;
                        groupBox.Margin = margin;
                        StackPanel sPanel = new StackPanel();
                        sPanel.Width = double.NaN;
                        sPanel.Height = double.NaN;
                        sPanel.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
                        sPanel.VerticalAlignment = System.Windows.VerticalAlignment.Stretch;

                        foreach (Tuple<string, string> file in dataset.Files)
                        {
                            TextBlock block = new TextBlock();
                            block.FontWeight = FontWeights.Normal;
                            block.Margin = margin;
                            block.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                            block.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                            block.Text = file.Item2;
                            ProgressBar progress = new ProgressBar();
                            progress.Margin = margin;
                            progress.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
                            progress.VerticalAlignment = System.Windows.VerticalAlignment.Bottom;
                            progress.Width = double.NaN;
                            progress.Height = 6;
                            sPanel.Children.Add(block);
                            sPanel.Children.Add(progress);
                            numTasks++;
                        }
                        groupBox.Content = sPanel;
                        DownloadPanel.Children.Add(groupBox);
                    }
                }

                tasks = new Task[numTasks];
                Download();
            }
            else
                Close();
        }

        public void DownloadAsync(DatasetDownloadInformation info, Tuple<string, string> file, int headerIndex)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.BaseAddress = info.Url;
                    client.UseDefaultCredentials = true;
                    client.DownloadDataCompleted += new DownloadDataCompletedEventHandler(client_DownloadDataCompleted);
                    client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
                    int index = DataProvider.DataSetDownloadInfo.FindIndex(item => item == info);
                    int fileIndex = DataProvider.DataSetDownloadInfo[index].Files.FindIndex(item => item == file);

                    client.DownloadDataAsync(new Uri(file.Item1, UriKind.Relative), new Tuple<int, int, int>(headerIndex, index, fileIndex));
                }
            }
            catch (Exception exception)
            {
                TaskDialogOptions config = new TaskDialogOptions();
                config.Owner = this;
                config.MainIcon = VistaTaskDialogIcon.Information;
                config.MainInstruction = exception.Message;
                config.Title = "Information";
                config.CommandButtons = new string[] { "&OK" };
                config.AllowDialogCancellation = false;
                TaskDialog.Show(config);
                Interlocked.Increment(ref errors);
            }
        }

        public void Download()
        {
            try
            {
                int taskIndex = 0;
                int headerIndex = 0;
                if (!DataProvider.DataSetFilesAvailable(DataProviderSets.CIFAR10))
                {
                    int hIdx = headerIndex;
                    foreach (Tuple<string, string> file in DataProvider.DataSetDownloadInfo[(int)DataProviderSets.CIFAR10].Files)
                        tasks[taskIndex++] = new Task(() => { DownloadAsync(DataProvider.DataSetDownloadInfo[(int)DataProviderSets.CIFAR10], file, hIdx); });

                    Interlocked.Increment(ref headerIndex);
                }
                if (!DataProvider.DataSetFilesAvailable(DataProviderSets.MNIST))
                {
                    int hIdx = headerIndex;
                    foreach (Tuple<string, string> file in DataProvider.DataSetDownloadInfo[(int)DataProviderSets.MNIST].Files)
                        tasks[taskIndex++] = new Task(() => { DownloadAsync(DataProvider.DataSetDownloadInfo[(int)DataProviderSets.MNIST], file, hIdx); });

                    Interlocked.Increment(ref headerIndex);
                }

                foreach (Task task in tasks)
                    task.Start();
               
                Task.WaitAll(tasks);
            }
            catch (AggregateException exception)
            {
                TaskDialogOptions config = new TaskDialogOptions();
                config.Owner = this;
                config.MainIcon = VistaTaskDialogIcon.Warning;
                config.MainInstruction = exception.Message;
                config.Title = "Warning";
                config.CommandButtons = new string[] { "&OK" };
                config.AllowDialogCancellation = false;
                TaskDialog.Show(config);
                Interlocked.Increment(ref errors);
            }
        }

        private bool AllTasksCompleted()
        {
            return (tasksCompleted == numTasks);
        }

        private void client_DownloadProgressChanged(System.Object sender, DownloadProgressChangedEventArgs e)
        {
            Dispatcher.Invoke(showProgress, System.Windows.Threading.DispatcherPriority.Render, new object[] { sender, e });
        }

        private void client_DownloadDataCompleted(System.Object sender, DownloadDataCompletedEventArgs e)
        {
            Dispatcher.Invoke(downloadFinished, System.Windows.Threading.DispatcherPriority.Render, new object[] { sender, e });
        }

        private void ShowProgress(System.Object sender, DownloadProgressChangedEventArgs e)
        {
            double kilobytesReceived = (double)Math.Truncate(double.Parse(e.BytesReceived.ToString()) / 1024D);
            double totalKiloBytesToReceive = (double)Math.Truncate(double.Parse(e.TotalBytesToReceive.ToString()) / 1024D);
            Tuple<int, int, int> pos = e.UserState as Tuple<int, int, int>;
           
            GroupBox gb = DownloadPanel.Children[pos.Item1] as GroupBox;
            StackPanel sp = gb.Content as StackPanel;
            TextBlock tb = sp.Children[pos.Item3 * 2] as TextBlock;
            ProgressBar pb = sp.Children[(pos.Item3 * 2) + 1] as ProgressBar;
            tb.Text = DataProvider.DataSetDownloadInfo[pos.Item2].Files[pos.Item3].Item2 + " (" + kilobytesReceived.ToString() + "/" + totalKiloBytesToReceive.ToString() + " KiloBytes)";
            pb.Value = e.ProgressPercentage;
        }

        private void DownloadFinished(Object sender, DownloadDataCompletedEventArgs e)
        {
            try
            {
                Tuple<int, int, int> pos = e.UserState as Tuple<int, int, int>;
                string fileName = DataProvider.DataSetDownloadInfo[pos.Item2].Files[pos.Item3].Item1.Remove(DataProvider.DataSetDownloadInfo[pos.Item2].Files[pos.Item3].Item1.Length - 3, 3);
                string archivePath = DataProvider.DataSetDownloadInfo[pos.Item2].Path;

                if (File.Exists(archivePath + @"\" + fileName))
                    File.Delete(archivePath + @"\" + fileName);

                using (MemoryStream memoryStream = new MemoryStream(e.Result, false))
                {
                    using (System.IO.Compression.GZipStream zipStream = new GZipStream(memoryStream, CompressionMode.Decompress, false))
                    {
                        using (System.IO.FileStream fileStream = new FileStream(archivePath + @"\" + fileName, FileMode.Create, FileAccess.ReadWrite))
                        {
                            zipStream.CopyTo(fileStream);
                            fileStream.Flush(true);
                        }
                    }
                }

                switch (DataProvider.DataSetDownloadInfo[pos.Item2].DataProviderSet)
                {
                    case DataProviderSets.MNIST:
                        break;

                    case DataProviderSets.CIFAR10:
                        try
                        {
                            ExtractTar(archivePath + @"\cifar-10-binary.tar", archivePath);

                            File.Move(archivePath + @"\cifar-10-batches-bin\data_batch_1.bin", archivePath + @"\data_batch_1.bin");
                            File.Move(archivePath + @"\cifar-10-batches-bin\data_batch_2.bin", archivePath + @"\data_batch_2.bin");
                            File.Move(archivePath + @"\cifar-10-batches-bin\data_batch_3.bin", archivePath + @"\data_batch_3.bin");
                            File.Move(archivePath + @"\cifar-10-batches-bin\data_batch_4.bin", archivePath + @"\data_batch_4.bin");
                            File.Move(archivePath + @"\cifar-10-batches-bin\data_batch_5.bin", archivePath + @"\data_batch_5.bin");
                            File.Move(archivePath + @"\cifar-10-batches-bin\test_batch.bin", archivePath + @"\test_batch.bin");
                            File.Move(archivePath + @"\cifar-10-batches-bin\batches.meta.txt", archivePath + @"\batches.meta.txt");
                            File.Move(archivePath + @"\cifar-10-batches-bin\readme.html", archivePath + @"\readme.html");

                            Directory.Delete(archivePath + @"\cifar-10-batches-bin");
                            File.Delete(archivePath + @"\cifar-10-binary.tar");
                        }
                        catch (Exception exception) 
                        {
                            TaskDialogOptions config = new TaskDialogOptions();
                            config.Owner = this;
                            config.MainIcon = VistaTaskDialogIcon.Warning;
                            config.MainInstruction = exception.Message;
                            config.Title = "Warning";
                            config.CommandButtons = new string[] { "&OK" };
                            config.AllowDialogCancellation = false;
                            TaskDialog.Show(config);
                            Interlocked.Increment(ref errors);
                        }
                        break;
                }
            }
            catch (Exception exception)
            {
                TaskDialogOptions config = new TaskDialogOptions();
                config.Owner = this;
                config.MainIcon = VistaTaskDialogIcon.Warning;
                config.MainInstruction = exception.Message;
                config.Title = "Warning";
                config.CommandButtons = new string[] { "&OK" };
                config.AllowDialogCancellation = false;
                TaskDialog.Show(config);
                Interlocked.Increment(ref errors);
            }
            finally
            {
                (sender as WebClient).DownloadProgressChanged -= new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
                (sender as WebClient).DownloadDataCompleted -= new DownloadDataCompletedEventHandler(client_DownloadDataCompleted);
            }

            Interlocked.Increment(ref tasksCompleted);

            if (AllTasksCompleted())
            {
                AllDownloaded = true;
                this.Close();
            }
        }

        public void ExtractTar(String ArchiveName, String destFolder)
        {
            using (FileStream inStream = File.OpenRead(ArchiveName))
            {
                using (TarArchive tarArchive = TarArchive.CreateInputTarArchive(inStream))
                {
                    tarArchive.ExtractContents(destFolder);
                }
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!AllDownloaded)
            {
                TaskDialogOptions dialog = new TaskDialogOptions();
                dialog.Owner = this;
                dialog.MainIcon = VistaTaskDialogIcon.Information;
                dialog.MainInstruction = "Cancel downloading datasets ?";
                dialog.Title = "Exiting application";
                dialog.CustomButtons = new string[] { "&Yes", "&No" };
                dialog.DefaultButtonIndex = 1;
                dialog.AllowDialogCancellation = false;
                TaskDialogResult res = TaskDialog.Show(dialog);
                if (res.CustomButtonResult == 0)
                    e.Cancel = false;
                else
                    e.Cancel = true;
            }
            else
            {
                if (tasks != null)
                {
                    foreach (Task task in tasks)
                    {
                        if (task != null)
                            task.Dispose();
                    }
                    tasks = null;
                }
                
                if (errors != 0)
                {
                    AllDownloaded = false;
                    TaskDialogOptions dialog = new TaskDialogOptions();
                    dialog.Owner = this;
                    dialog.MainIcon = VistaTaskDialogIcon.Warning;
                    dialog.MainInstruction = "Some error(s) occured. \r\nApplication will exit.";
                    dialog.Title = "Exiting application";
                    dialog.CustomButtons = new string[] { "&Ok" };
                    dialog.DefaultButtonIndex = 0;
                    dialog.AllowDialogCancellation = false;
                    TaskDialogResult res = TaskDialog.Show(dialog);
                }
            }
        }
    }
}
