﻿using System.Windows;

namespace CNNWB.Dialogs
{
    /// <summary>
    /// Interaction logic for Info.xaml
    /// </summary>
    public partial class About : Window
    {
        public About()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            textBlockAssemblyVersion.Text = "Assembly Version " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
        }
    }
}
