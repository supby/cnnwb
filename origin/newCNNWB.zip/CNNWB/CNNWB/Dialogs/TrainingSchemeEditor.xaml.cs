﻿using CNNWB.Model;
using CNNWB.ViewModel;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using TaskDialogInterop;

namespace CNNWB.Dialogs
{
    /// <summary>
    /// Interaction logic for TrainingSchemeEditor.xaml
    /// </summary>
    public partial class TrainingSchemeEditor : Window
    {
        public PageViewModel pageViewModel { get; set; }
        public TrainingRate Rate { get; set; }
        public string Path { get; set; }
        
        private ObservableCollection<TrainingRate> defaultList = new ObservableCollection<TrainingRate>();
        private Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
        private Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();

        public TrainingSchemeEditor()
        {
            Rate = new TrainingRate();
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            defaultList.Add(Rate);
            dataGridRates.ItemsSource = defaultList;
            DataContext = defaultList;
            dataGridRates.CanUserAddRows = true;
            dataGridRates.CanUserDeleteRows = true;
            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGD) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGD))
            {
                dataGridRates.Columns[3].Visibility = System.Windows.Visibility.Visible;    // show the WeightDecayFactor field
                dataGridRates.Columns[4].Visibility = System.Windows.Visibility.Hidden;     // hide the Momentum field
            }
            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDM) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGDM))
            {
                dataGridRates.Columns[3].Visibility = System.Windows.Visibility.Hidden;     // hide the WeightDecayFactor field
                dataGridRates.Columns[4].Visibility = System.Windows.Visibility.Visible;    // show the Momentum field
            }

            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardt) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGDLevenbergMarquardt) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardtModA) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGDLevenbergMarquardtModA))
            {
                dataGridRates.Columns[3].Visibility = System.Windows.Visibility.Hidden;     // hide the WeightDecayFactor field
                dataGridRates.Columns[4].Visibility = System.Windows.Visibility.Hidden;     // hide the Momentum field
            }

            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGD) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardt) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardtModA) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDM))
                dataGridRates.Columns[5].Visibility = System.Windows.Visibility.Visible;    // show the  BatchSize field
            else
                dataGridRates.Columns[5].Visibility = System.Windows.Visibility.Hidden;     // hide the field
            
            dataGridRates.Columns[6].Visibility = System.Windows.Visibility.Hidden;         // always hide InitialAvgLoss field
        }

        private void buttonInsert_Click(object sender, RoutedEventArgs e)
        {
            int selectedIndex = dataGridRates.SelectedIndex;
            if (selectedIndex != -1)
            {
                defaultList.Insert(selectedIndex, new TrainingRate());
                dataGridRates.SelectedIndex = selectedIndex;
                dataGridRates.Focus();
            }
        }

        private void buttonTrain_Click(object sender, RoutedEventArgs e)
        {
            bool first = true;
            
            foreach (TrainingRate rate in defaultList)
            {
                pageViewModel.NeuralNetwork.AddGlobalTrainingRate(rate, first);
                first = false;
            }
            
            DialogResult = true;
            this.Close();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            saveFileDialog.InitialDirectory = Path;
            saveFileDialog.Filter = "Xml Training Scheme|*.scheme-xml";
            saveFileDialog.DefaultExt = ".scheme-xml";
            saveFileDialog.AddExtension = true;
            saveFileDialog.CreatePrompt = false;
            saveFileDialog.OverwritePrompt = true;
            saveFileDialog.ValidateNames = true;

            if (saveFileDialog.ShowDialog(this) == true)
            {
                string fileName = saveFileDialog.FileName;

                Mouse.OverrideCursor = Cursors.Wait;
                if (fileName.Contains("scheme-xml"))
                {
                    using (CNNDataSet.TrainingRatesDataTable table = new CNNDataSet.TrainingRatesDataTable())
                    {
                        table.BeginLoadData();
                        foreach (TrainingRate rate in defaultList)
                            table.AddTrainingRatesRow(rate.Rate, rate.Epochs, rate.MinimumRate, rate.WeightDecayFactor, rate.Momentum, rate.BatchSize, rate.InitialAvgLoss, rate.DecayFactor, rate.DecayAfterEpochs, rate.WeightSaveTreshold, rate.Distorted, rate.DistortionPercentage, rate.SeverityFactor, rate.MaxScaling, rate.MaxRotation, rate.ElasticSigma, rate.ElasticScaling);
                        table.EndLoadData();
                        table.WriteXml(fileName, System.Data.XmlWriteMode.WriteSchema);
                    }
                    Mouse.OverrideCursor = null;
                    this.Title = "Training Scheme Editor - " + saveFileDialog.SafeFileName.Replace(".scheme-xml", "");
                    TaskDialogOptions config = new TaskDialogOptions();
                    config.Owner = this;
                    config.MainIcon = VistaTaskDialogIcon.Information;
                    config.MainInstruction = "Training scheme is saved.";
                    config.Title = "Information";
                    config.CommandButtons = new string[] { "&OK" };
                    config.AllowDialogCancellation = false;
                    TaskDialog.Show(config);
                }
            }
            Mouse.OverrideCursor = null;
        }

        private void buttonLoad_Click(object sender, RoutedEventArgs e)
        {
            openFileDialog.InitialDirectory = Path;
            openFileDialog.Filter= "Xml Training Scheme|*.scheme-xml";
            openFileDialog.Title = "Load Training Scheme";
            openFileDialog.DefaultExt = ".scheme-xml";
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.Multiselect = false;
            openFileDialog.ValidateNames = true;

            bool stop = false;
            while (!stop)
            {
                if (openFileDialog.ShowDialog(this) == true)
                {
                    Mouse.OverrideCursor = Cursors.Wait;
                    string fileName = openFileDialog.FileName;

                    if (fileName.Contains(".scheme-xml"))
                    {
                        try
                        {
                            using (CNNDataSet.TrainingRatesDataTable table = new CNNDataSet.TrainingRatesDataTable())
                            {
                                table.ReadXml(fileName);

                                defaultList.Clear();

                                foreach (CNNDataSet.TrainingRatesRow row in table)
                                    defaultList.Add(new TrainingRate(row.Rate, row.Epochs, row.MinimumRate, row.WeightDecayFactor, row.Momentum, row.BatchSize, row.InitialAvgLoss, row.DecayFactor, row.DecayAfterEpochs, row.WeightSaveTreshold, row.Distorted, row.DistortionPercentage, row.SeverityFactor, row.MaxScaling, row.MaxRotation, row.ElasticSigma, row.ElasticScaling));
                            }

                            Mouse.OverrideCursor = null;
                            this.Title = "Training Scheme Editor - " + openFileDialog.SafeFileName.Replace(".scheme-xml", "");
                            stop = true;
                        }
                        catch (Exception)
                        {
                            Mouse.OverrideCursor = null;
                            TaskDialogOptions config = new TaskDialogOptions();
                            config.Owner = this;
                            config.MainIcon = VistaTaskDialogIcon.Warning;
                            config.MainInstruction = "Wrong file format.";
                            config.Title = "Choose an other file";
                            config.CommandButtons = new string[] { "&OK" };
                            config.AllowDialogCancellation = false;
                            TaskDialog.Show(config);
                        }
                    }
                    else
                    {
                        Mouse.OverrideCursor = null;
                        TaskDialogOptions config = new TaskDialogOptions();
                        config.Owner = this;
                        config.MainIcon = VistaTaskDialogIcon.Warning;
                        config.MainInstruction = "Wrong file naming format.";
                        config.Title = "Choose an other file name";
                        config.CommandButtons = new string[] { "&OK" };
                        config.AllowDialogCancellation = false;
                        TaskDialog.Show(config);
                    }
                }
                else
                    stop = true;
            }
            Mouse.OverrideCursor = null;
        }

      
    }
}
