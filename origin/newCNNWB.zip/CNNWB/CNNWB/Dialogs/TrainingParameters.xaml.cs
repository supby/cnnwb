﻿using CNNWB.Model;
using CNNWB.ViewModel;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using TaskDialogInterop;

namespace CNNWB
{
    /// <summary>
    /// Interaction logic for TrainingParameters.xaml
    /// </summary>
    public partial class TrainingParameters : Window
    {
        public PageViewModel pageViewModel { get; set; }
        public TrainingRate Data { get; set; }
        public string Path { get; set; }
        private Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
        private Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
       
        public TrainingParameters()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DataContext = Data;
            textBoxNumberOfEpochs.Focus();

            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGD) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardt) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardtModA) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDM))
            {
                textBlockBatchSize.Opacity = 1;
                textBoxBatchSize.IsEnabled = true;
            }
            else
            {
                textBlockBatchSize.Opacity = 0.5;
                textBoxBatchSize.IsEnabled = false;
            }

            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGD) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGD))
            {
                textBlockWeightDecayFactor.Opacity = 1;
                textBoxWeightDecayFactor.IsEnabled = true;
                textBlockMomentum.Opacity = 0.5;
                textBoxMomentum.IsEnabled = false;
            }

            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDM) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGDM))
            {
                textBlockWeightDecayFactor.Opacity = 0.5;
                textBoxWeightDecayFactor.IsEnabled = false;
                textBlockMomentum.Opacity = 1;
                textBoxMomentum.IsEnabled = true;
            }

            if ((pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardt) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGDLevenbergMarquardt) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.MiniBatchSGDLevenbergMarquardtModA) || (pageViewModel.NeuralNetwork.TrainingStrategy == TrainingStrategy.SGDLevenbergMarquardtModA))
            {
                textBlockWeightDecayFactor.Opacity = 0.5;
                textBoxWeightDecayFactor.IsEnabled = false;
                textBlockMomentum.Opacity = 0.5;
                textBoxMomentum.IsEnabled = false;
            }
        }

        bool IsValid(DependencyObject node)
        {
            // Check if dependency object was passed
            if (node != null)
            {
                // Check if dependency object is valid.
                // NOTE: Validation.GetHasError works for controls that have validation rules attached 
                bool isValid = !Validation.GetHasError(node);
                if (!isValid)
                {
                    // If the dependency object is invalid, and it can receive the focus,
                    // set the focus
                    if (node is IInputElement) Keyboard.Focus((IInputElement)node);
                    return false;
                }
            }

            // If this dependency object is valid, check all child dependency objects
            foreach (object subnode in LogicalTreeHelper.GetChildren(node))
            {
                if (subnode is DependencyObject)
                {
                    // If a child dependency object is invalid, return false immediately,
                    // otherwise keep checking
                    if (IsValid((DependencyObject)subnode) == false) return false;
                }

            }

            // All dependency objects are valid
            return true;
        }

        private void buttonLoad_Click(object sender, RoutedEventArgs e)
        {
            openFileDialog.InitialDirectory = Path;
            openFileDialog.Filter = "Xml Training Parameters|*.parameters-xml";
            openFileDialog.Title = "Load Training Parameters";
            openFileDialog.DefaultExt = ".parameters-xml";
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.Multiselect = false;
            openFileDialog.ValidateNames = true;

            bool stop = false;
            while (!stop)
            {
                if (openFileDialog.ShowDialog(this) == true)
                {
                    Mouse.OverrideCursor = Cursors.Wait;
                    string fileName = openFileDialog.FileName;

                    if (fileName.Contains(".parameters-xml"))
                    {
                        try
                        {
                            using (CNNDataSet.TrainingRatesDataTable table = new CNNDataSet.TrainingRatesDataTable())
                            {
                                table.ReadXml(fileName);
                                CNNDataSet.TrainingRatesRow row = table.Rows[0] as CNNDataSet.TrainingRatesRow;
                                Data = new TrainingRate(row.Rate, row.Epochs, row.MinimumRate, row.WeightDecayFactor, row.Momentum, row.BatchSize, row.InitialAvgLoss, row.DecayFactor, row.DecayAfterEpochs, row.WeightSaveTreshold, row.Distorted, row.DistortionPercentage, row.SeverityFactor, row.MaxScaling, row.MaxRotation, row.ElasticSigma, row.ElasticScaling);
                                DataContext = Data;
                            }

                            Properties.Settings.Default.Rate = Data.Rate;
                            Properties.Settings.Default.Epochs = Data.Epochs;
                            Properties.Settings.Default.MinimumRate = Data.MinimumRate;
                            Properties.Settings.Default.WeightDecayFactor = Data.WeightDecayFactor;
                            Properties.Settings.Default.Momentum = Data.Momentum;
                            Properties.Settings.Default.BatchSize = Data.BatchSize;
                            Properties.Settings.Default.InitialAvgLoss = Data.InitialAvgLoss;
                            Properties.Settings.Default.DecayFactor = Data.DecayFactor;
                            Properties.Settings.Default.DecayAfterEpochs = Data.DecayAfterEpochs;
                            Properties.Settings.Default.WeightSaveTreshold = Data.WeightSaveTreshold;
                            Properties.Settings.Default.Distorted = Data.Distorted;
                            Properties.Settings.Default.DistortionPercentage = Data.DistortionPercentage;
                            Properties.Settings.Default.SeverityFactor = Data.SeverityFactor;
                            Properties.Settings.Default.MaxScaling = Data.MaxScaling;
                            Properties.Settings.Default.MaxRotation = Data.MaxRotation;
                            Properties.Settings.Default.ElasticSigma = Data.ElasticSigma;
                            Properties.Settings.Default.ElasticScaling = Data.ElasticScaling;
                            Properties.Settings.Default.Save();

                            Mouse.OverrideCursor = null;
                            this.Title = "Training Parameters - " + openFileDialog.SafeFileName.Replace(".parameters-xml", "");
                            stop = true;
                        }
                        catch (Exception)
                        {
                            Mouse.OverrideCursor = null;
                            TaskDialogOptions config = new TaskDialogOptions();
                            config.Owner = this;
                            config.MainIcon = VistaTaskDialogIcon.Warning;
                            config.MainInstruction = "Wrong file format.";
                            config.Title = "Choose an other file";
                            config.CommandButtons = new string[] { "&OK" };
                            config.AllowDialogCancellation = false;
                            TaskDialog.Show(config);
                        }
                    }
                    else
                    {
                        Mouse.OverrideCursor = null;
                        TaskDialogOptions config = new TaskDialogOptions();
                        config.Owner = this;
                        config.MainIcon = VistaTaskDialogIcon.Warning;
                        config.MainInstruction = "Wrong file naming format.";
                        config.Title = "Choose a different file name";
                        config.CommandButtons = new string[] { "&OK" };
                        config.AllowDialogCancellation = false;
                        TaskDialog.Show(config);
                    }
                }
                else
                    stop = true;
            }
            Mouse.OverrideCursor = null;
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            if (IsValid(this))
            {
                saveFileDialog.InitialDirectory = Path;
                saveFileDialog.Filter = "Xml Training Parameters|*.parameters-xml";
                saveFileDialog.DefaultExt = ".parameters-xml";
                saveFileDialog.AddExtension = true;
                saveFileDialog.CreatePrompt = false;
                saveFileDialog.OverwritePrompt = true;
                saveFileDialog.ValidateNames = true;

                if (saveFileDialog.ShowDialog(this) == true)
                {
                    string fileName = saveFileDialog.FileName;

                    Mouse.OverrideCursor = Cursors.Wait;
                    if (fileName.Contains("parameters-xml"))
                    {
                        using (CNNDataSet.TrainingRatesDataTable table = new CNNDataSet.TrainingRatesDataTable())
                        {
                            table.BeginLoadData();
                            table.AddTrainingRatesRow(Data.Rate, Data.Epochs, Data.MinimumRate, Data.WeightDecayFactor, Data.Momentum, Data.BatchSize, Data.InitialAvgLoss, Data.DecayFactor, Data.DecayAfterEpochs, Data.WeightSaveTreshold, Data.Distorted, Data.DistortionPercentage, Data.SeverityFactor, Data.MaxScaling, Data.MaxRotation, Data.ElasticSigma, Data.ElasticScaling);
                            table.EndLoadData();
                            table.WriteXml(fileName, System.Data.XmlWriteMode.WriteSchema);
                        }
                        Mouse.OverrideCursor = null;
                        this.Title = "Training Parameters - " + saveFileDialog.SafeFileName.Replace(".parameters-xml", "");
                        TaskDialogOptions config = new TaskDialogOptions();
                        config.Owner = this;
                        config.MainIcon = VistaTaskDialogIcon.Information;
                        config.MainInstruction = "Training parameters are saved.";
                        config.Title = "Information";
                        config.CommandButtons = new string[] { "&OK" };
                        config.AllowDialogCancellation = false;
                        TaskDialog.Show(config);
                    }

                    Properties.Settings.Default.Epochs = Data.Epochs;
                    Properties.Settings.Default.Rate = Data.Rate;
                    Properties.Settings.Default.MinimumRate = Data.MinimumRate;
                    Properties.Settings.Default.WeightDecayFactor = Data.WeightDecayFactor;
                    Properties.Settings.Default.Momentum = Data.Momentum;
                    Properties.Settings.Default.BatchSize = Data.BatchSize;
                    Properties.Settings.Default.InitialAvgLoss = Data.InitialAvgLoss;
                    Properties.Settings.Default.DecayFactor = Data.DecayFactor;
                    Properties.Settings.Default.DecayAfterEpochs = Data.DecayAfterEpochs;
                    Properties.Settings.Default.WeightSaveTreshold = Data.WeightSaveTreshold;
                    Properties.Settings.Default.Distorted = Data.Distorted;
                    Properties.Settings.Default.DistortionPercentage = Data.DistortionPercentage;
                    Properties.Settings.Default.SeverityFactor = Data.SeverityFactor;
                    Properties.Settings.Default.MaxScaling = Data.MaxScaling;
                    Properties.Settings.Default.MaxRotation = Data.MaxRotation;
                    Properties.Settings.Default.ElasticSigma = Data.ElasticSigma;
                    Properties.Settings.Default.ElasticScaling = Data.ElasticScaling;
                    Properties.Settings.Default.Save();

                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void buttonTrain_Click(object sender, RoutedEventArgs e)
        {
            if (IsValid(this))
            {
                Properties.Settings.Default.Epochs = Data.Epochs;
                Properties.Settings.Default.Rate = Data.Rate;
                Properties.Settings.Default.MinimumRate = Data.MinimumRate;
                Properties.Settings.Default.WeightDecayFactor = Data.WeightDecayFactor;
                Properties.Settings.Default.Momentum = Data.Momentum;
                Properties.Settings.Default.BatchSize = Data.BatchSize;
                Properties.Settings.Default.InitialAvgLoss = Data.InitialAvgLoss;
                Properties.Settings.Default.DecayFactor = Data.DecayFactor;
                Properties.Settings.Default.DecayAfterEpochs = Data.DecayAfterEpochs;
                Properties.Settings.Default.WeightSaveTreshold = Data.WeightSaveTreshold;
                Properties.Settings.Default.Distorted = Data.Distorted;
                Properties.Settings.Default.DistortionPercentage = Data.DistortionPercentage;
                Properties.Settings.Default.SeverityFactor = Data.SeverityFactor;
                Properties.Settings.Default.MaxScaling = Data.MaxScaling;
                Properties.Settings.Default.MaxRotation = Data.MaxRotation;
                Properties.Settings.Default.ElasticSigma = Data.ElasticSigma;
                Properties.Settings.Default.ElasticScaling = Data.ElasticScaling;
                Properties.Settings.Default.Save();

                pageViewModel.NeuralNetwork.AddGlobalTrainingRate(Data, true);
                DialogResult = true;
                this.Close();
            }
        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
