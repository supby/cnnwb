﻿using CNNWB.Model;
using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CNNWB.Common
{
    public sealed class ConfusionMatrix : ObservableCollection<ConfusionItems>
    {
        private string name;
        private DataProvider dataProvider;

        public ConfusionMatrix(string name, DataProvider dataProvider) : base()
        {
            Name = name;
            DataProvider = dataProvider;
        }

        public String Name
        {
            get { return name; }
            set
            {
                if (value == name)
                    return;

                name = value;
                base.OnPropertyChanged(new PropertyChangedEventArgs("Name"));
            }
        }

        public DataProvider DataProvider
        {
            get { return dataProvider; }
            set
            {
                if (value == dataProvider)
                    return;

                dataProvider = value;

                if (dataProvider != null)
                    for (int i = 0; i < dataProvider.ClassCount; i++)
                        base.Add(new ConfusionItems(i, dataProvider));

                base.OnPropertyChanged(new PropertyChangedEventArgs("DataProvider"));
            }
        }
    }

    public class ConfusionItems : TabItem, INotifyPropertyChanged 
    {
        private ObservableCollection<ConfusedItem> items;
        private int correctValue;
        private DataProvider dataProvider;
        private WrapPanel panel;
        private ScrollViewer scr;
        
        public int CorrectValue 
        { 
            get
            {
                return correctValue;
            } 

            private set
            {
                if (value == correctValue)
                    return;
 
                correctValue = value;

                this.OnPropertyChanged ("CorrectValue");
            }
        }

        public DataProvider DataProvider
        {
            get
            {
                return dataProvider;
            }

            private set
            {
                if (value == dataProvider)
                    return;

                dataProvider = value;
                this.OnPropertyChanged("DataProvider");
            }
        }

        public ObservableCollection<ConfusedItem> Items
        {
            get
            {
                return (items);
            }

            private set
            {
                if (value == items)
                    return;

                items = value;

                this.OnPropertyChanged("Items");
            }
        }

        public ConfusionItems(int correctValue, DataProvider dataProvider) : base()
        {
            DataProvider = dataProvider;
            CorrectValue = correctValue;
            Items = new ObservableCollection<ConfusedItem>();
            panel = new WrapPanel();
            scr = new ScrollViewer();
            GetConfusedItems();
            panel.SnapsToDevicePixels = false;
            panel.UseLayoutRounding = false;
            panel.Orientation = Orientation.Horizontal;
            panel.HorizontalAlignment = HorizontalAlignment.Stretch;
            panel.VerticalAlignment = VerticalAlignment.Stretch;
            scr.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            scr.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
            scr.HorizontalContentAlignment = HorizontalAlignment.Stretch;
            scr.VerticalContentAlignment = VerticalAlignment.Stretch;
            scr.VerticalAlignment = VerticalAlignment.Stretch;
            scr.HorizontalAlignment = HorizontalAlignment.Stretch;
            scr.UseLayoutRounding = false;
            scr.SnapsToDevicePixels = false;
            scr.Content = panel;
            scr.Height = double.NaN;
            scr.Width = double.NaN;
            Content = scr;
            Items.CollectionChanged += new NotifyCollectionChangedEventHandler(Items_CollectionChanged);
        }

        ~ConfusionItems()
        {
            Items.CollectionChanged -= new NotifyCollectionChangedEventHandler(Items_CollectionChanged);
            Items = null;
        }

        public void Items_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            GetConfusedItems();
        }

        public void GetConfusedItems()
        {
            panel.BeginInit();
            foreach (ConfusedItem wrongImage in Items)
                if ((wrongImage != null) && !panel.Children.Contains(wrongImage))
                    panel.Children.Add(wrongImage);
            panel.EndInit();

            if (DataProvider != null)
            {
                if (DataProvider.CurrentDataSet == DataProviderSets.MNIST)
                    Header = CorrectValue.ToString() + " (" + Items.Count.ToString() + ")";
                else
                {
                    CIFAR10Classes label = (CIFAR10Classes)CorrectValue;
                    Header = label.ToString() + " (" + Items.Count.ToString() + ")";
                }
            }
            else
                Header = CorrectValue.ToString() + " (" + Items.Count.ToString() + ")";
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion // INotifyPropertyChanged Members
    }

    public sealed class ConfusedItem: Grid 
    {
        private int sampleIndex;
        private int wrongValue;
        private ImageData sample;
       
        public int SampleIndex 
        { 
            get 
            {
                return sampleIndex;
            }
            private set
            {
                if (value == sampleIndex)
                    return;

                sampleIndex = value;
            }
        }
        
        public int WrongValue 
        {
            get
            {
                return wrongValue;
            }
            private set
            {
                if (value == wrongValue)
                    return;

                wrongValue = value;
            }
        }

        public ImageData Sample
        {
            get
            {
                return sample;
            }
            private set
            {
                sample = value;
            }
        }

        public ConfusedItem(int sampleIndex, int wrongValue, ImageData sample, DataProvider dataProvider)
        {
            SampleIndex = sampleIndex;
            WrongValue = wrongValue;
            Sample = sample;

            BeginInit();
            Background = System.Windows.Media.Brushes.White;
            SnapsToDevicePixels = false;
            UseLayoutRounding = false;
            HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch;
            VerticalAlignment = System.Windows.VerticalAlignment.Stretch;
            Width = 78;
            Height = 78;
            Margin = new Thickness(2);

            ColumnDefinitions.Add(new ColumnDefinition());
            RowDefinition row0 = new RowDefinition();
            row0.Height = new GridLength(34);
            RowDefinitions.Add(row0);
            RowDefinition row1 = new RowDefinition();
            row1.Height = new GridLength(0, GridUnitType.Auto);
            RowDefinitions.Add(row1);
            RowDefinition row2 = new RowDefinition();
            row2.Height = new GridLength(0, GridUnitType.Auto);
            RowDefinitions.Add(row2);

            System.Windows.Shapes.Rectangle rectangle = new System.Windows.Shapes.Rectangle();
            rectangle.HorizontalAlignment = HorizontalAlignment.Stretch;
            rectangle.VerticalAlignment = VerticalAlignment.Stretch;
            rectangle.Margin = new Thickness(1);
            rectangle.Height = double.NaN;
            rectangle.Width = double.NaN;
            rectangle.SnapsToDevicePixels = false;
            rectangle.UseLayoutRounding = false;
            rectangle.Stretch = Stretch.UniformToFill;
            rectangle.StrokeThickness = 1;
            rectangle.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
            rectangle.Fill = System.Windows.Media.Brushes.Transparent;

            Grid.SetColumn(rectangle, 0);
            Grid.SetRow(rectangle, 0);
            Grid.SetRowSpan(rectangle, 3);

            System.Windows.Controls.Image wImage = new System.Windows.Controls.Image();
            wImage.Source = Sample.GetBitmapSource(dataProvider);
            wImage.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            wImage.VerticalAlignment = System.Windows.VerticalAlignment.Center;
            wImage.Stretch = System.Windows.Media.Stretch.None;
            wImage.SnapsToDevicePixels = false;
            wImage.UseLayoutRounding = false;
            wImage.MinHeight = 32;
            wImage.MaxHeight = 32;
            wImage.MinWidth = 32;
            wImage.MaxWidth = 32;
            wImage.Margin = new Thickness(1);

            Grid.SetColumn(wImage, 0);
            Grid.SetRow(wImage, 0);

            TextBlock patternIndexTextBlock = new TextBlock();
            patternIndexTextBlock.FontSize = 11;
            patternIndexTextBlock.TextAlignment = System.Windows.TextAlignment.Center;
            patternIndexTextBlock.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            patternIndexTextBlock.VerticalAlignment = System.Windows.VerticalAlignment.Center;
            patternIndexTextBlock.Margin = new Thickness(1);
            patternIndexTextBlock.Text = SampleIndex.ToString(CultureInfo.CurrentUICulture);
            patternIndexTextBlock.Height = double.NaN;
            patternIndexTextBlock.Width = double.NaN;
            Grid.SetColumn(patternIndexTextBlock, 0);
            Grid.SetRow(patternIndexTextBlock, 1);

            TextBlock wrongValueTextBlock = new TextBlock();
            wrongValueTextBlock.FontSize = 11;
            wrongValueTextBlock.TextAlignment = System.Windows.TextAlignment.Center;
            wrongValueTextBlock.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            wrongValueTextBlock.VerticalAlignment = System.Windows.VerticalAlignment.Center;
            wrongValueTextBlock.Margin = new Thickness(1);
            if (dataProvider.CurrentDataSet == DataProviderSets.MNIST)
                wrongValueTextBlock.Text = WrongValue.ToString(CultureInfo.CurrentUICulture);
            else
            {
                CIFAR10Classes label = (CIFAR10Classes)WrongValue;
                wrongValueTextBlock.Text = label.ToString();
            }
            wrongValueTextBlock.Height = double.NaN;
            wrongValueTextBlock.Width = double.NaN;
            Grid.SetColumn(wrongValueTextBlock, 0);
            Grid.SetRow(wrongValueTextBlock, 2);

            Children.Add(rectangle);
            Children.Add(wImage);
            Children.Add(patternIndexTextBlock);
            Children.Add(wrongValueTextBlock);
            EndInit();
        }
    }
}
