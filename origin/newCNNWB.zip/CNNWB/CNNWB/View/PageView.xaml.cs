﻿using System.Windows.Controls;

namespace CNNWB.View
{
    /// <summary>
    /// Interaction logic for View.xaml
    /// </summary>
    public partial class PageView : UserControl
    {
        public PageView()
        {
            InitializeComponent();
        }
    }
}
