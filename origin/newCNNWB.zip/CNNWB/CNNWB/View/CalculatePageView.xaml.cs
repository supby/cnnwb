﻿using CNNWB.ViewModel;
using System.Windows;
using System.Windows.Controls;
using Xceed.Wpf.Toolkit;

namespace CNNWB.View
{
    /// <summary>
    /// Interaction logic for CalculatePageView.xaml
    /// </summary>
    public partial class CalculatePageView : UserControl
    {
        private CalculatePageViewModel vm;
        
        public CalculatePageView()
        {
            InitializeComponent();
        }

        private void radioButtonTestingTrainingSet_Checked(object sender, RoutedEventArgs e)
        {
            if (radioButtonTestingTrainingSet.IsLoaded)
                if (DataContext != null)
                    IntegerUpDownSampleIndex.Value = 0;

            if (e != null)
                e.Handled = true;
        }

        private void radioButtonTestingTestingSet_Checked(object sender, RoutedEventArgs e)
        {
            if (radioButtonTestingTestingSet.IsLoaded)
                if (DataContext != null)
                    IntegerUpDownSampleIndex.Value = 0;

            if (e != null)
                e.Handled = true;
        }

        private void IntegerUpDownSampleIndex_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (DataContext != null)
            {
                vm = DataContext as CalculatePageViewModel;

                if (IntegerUpDownSampleIndex.Value >= 0)
                {
                    if (vm.UseTrainingSet && IntegerUpDownSampleIndex.Value >= vm.DataProvider.TrainingSamplesCount)
                    {
                        IntegerUpDownSampleIndex.Value = 0;
                        if (e != null)
                            e.Handled = true;
                        return;
                    }

                    if (!vm.UseTrainingSet && IntegerUpDownSampleIndex.Value >= vm.DataProvider.TestingSamplesCount)
                    {
                        IntegerUpDownSampleIndex.Value = 0;
                        if (e != null)
                            e.Handled = true;
                        return;
                    }

                    vm.SampleIndex = (int)IntegerUpDownSampleIndex.Value;
                    if (e != null)
                        e.Handled = true;
                }
                else
                {
                    IntegerUpDownSampleIndex.Value = 0;
                    if (e != null)
                        e.Handled = true;
                }
            }   
        }

        private void IntegerUpDownSampleIndex_MouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
            if (DataContext != null)
            {
                int? x = (sender as IntegerUpDown).Value;
                x += e.Delta;

                if (x >= 0)
                    (sender as IntegerUpDown).Value = x;
                else
                    (sender as IntegerUpDown).Value = 0;

                e.Handled = true;
            }
        }

        private void IntegerUpDownSampleIndex_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (DataContext != null)
            {
                int? x = (sender as IntegerUpDown).Value;

                switch (e.Key)
                {
                    case System.Windows.Input.Key.Up:
                        x++;
                        e.Handled = true;
                        break;

                    case System.Windows.Input.Key.Down:
                        x--;
                        e.Handled = true;
                        break;

                    case System.Windows.Input.Key.PageUp:
                        x += 100;
                        e.Handled = true;
                        break;

                    case System.Windows.Input.Key.PageDown:
                        x -= 100;
                        e.Handled = true;
                        break;
                }

                if (x >= 0)
                    (sender as IntegerUpDown).Value = x;
                else
                    (sender as IntegerUpDown).Value = 0;
            }
        }
    }
}
