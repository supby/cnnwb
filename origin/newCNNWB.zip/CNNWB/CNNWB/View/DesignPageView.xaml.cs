﻿using System.Windows.Controls;

namespace CNNWB.View
{
    /// <summary>
    /// Interaction logic for DesignPageView.xaml
    /// </summary>
    public partial class DesignPageView : UserControl
    {
        public DesignPageView()
        {
            InitializeComponent();
        }
    }
}
