﻿using System.Windows.Controls;

namespace CNNWB.View
{
    /// <summary>
    /// Interaction logic for TestingPageView.xaml
    /// </summary>
    public partial class TestingPageView : UserControl
    {
        public TestingPageView()
        {
            InitializeComponent();
        }
    }
}
