﻿namespace CNNWB.Model {
    
    
    public partial class CNNDataSet {
        partial class TrainingRatesDataTable
        {
        }
    }
}
